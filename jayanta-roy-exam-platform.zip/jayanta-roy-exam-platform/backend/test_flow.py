"""End-to-end smoke test: seed -> login -> start -> save answers -> submit ->
result. Runs against in-memory SQLite + fakeredis so it needs no services.
Also verifies: version guard, deadline enforcement, resume, idempotent submit.
"""
import asyncio
import os

os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///./test.db"

import fakeredis.aioredis
from app import redis_client

# Patch the redis pool with fakeredis BEFORE anything uses it.
_fake = fakeredis.aioredis.FakeRedis(decode_responses=True)
redis_client.get_redis = lambda: _fake

import httpx
from app.main import app
from app import db as dbmod
from app.models import User, Exam, Question
from app.security import hash_password
from datetime import datetime, timedelta
from sqlalchemy import select


async def seed():
    async with dbmod.engine.begin() as conn:
        from app.db import Base
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    async with dbmod.SessionLocal() as s:
        s.add(User(roll_no="NEET0001", name="Cand 1",
                   password_hash=hash_password("test123"), role="candidate"))
        now = datetime.utcnow()
        exam = Exam(title="Mock", duration_minutes=180, marks_correct=4, marks_wrong=-1,
                    window_start=now - timedelta(minutes=1), window_end=now + timedelta(hours=3),
                    shuffle_questions=True, published=True)
        s.add(exam)
        await s.flush()
        for i in range(5):
            s.add(Question(exam_id=exam.id, section="Physics", text=f"Q{i}",
                           options={"A": "a", "B": "b", "C": "c", "D": "d"},
                           correct_option="A"))
        await s.commit()
        return exam.id


async def main():
    exam_id = await seed()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://t") as c:
        # login
        r = await c.post("/api/auth/login", json={"roll_no": "NEET0001", "password": "test123"})
        assert r.status_code == 200, r.text
        tok = r.json()["access_token"]
        H = {"Authorization": f"Bearer {tok}"}

        # wrong password
        assert (await c.post("/api/auth/login",
                json={"roll_no": "NEET0001", "password": "x"})).status_code == 401

        # start
        r = await c.post(f"/api/exams/{exam_id}/start", headers=H)
        assert r.status_code == 200, r.text
        state = r.json()
        aid = state["attempt_id"]
        qids = state["question_order"]
        assert len(qids) == 5
        print(f"  started attempt {aid[:8]} order={qids}")

        # save answer v1 = A (correct)
        r = await c.put(f"/api/attempts/{aid}/answers", headers=H,
                        json={"answers": [{"question_id": qids[0], "choice": "A", "state": "answered", "version": 1}]})
        assert r.json()["results"][str(qids[0])] == "OK", r.text

        # stale write (v1 again) must be rejected
        r = await c.put(f"/api/attempts/{aid}/answers", headers=H,
                        json={"answers": [{"question_id": qids[0], "choice": "B", "state": "answered", "version": 1}]})
        assert r.json()["results"][str(qids[0])] == "STALE", r.text

        # newer write (v2 = B, wrong) accepted
        r = await c.put(f"/api/attempts/{aid}/answers", headers=H,
                        json={"answers": [{"question_id": qids[0], "choice": "B", "state": "answered", "version": 2}]})
        assert r.json()["results"][str(qids[0])] == "OK"

        # answer q1 and q2 correctly
        await c.put(f"/api/attempts/{aid}/answers", headers=H,
                    json={"answers": [
                        {"question_id": qids[1], "choice": "A", "state": "answered", "version": 1},
                        {"question_id": qids[2], "choice": "A", "state": "answered", "version": 1},
                    ]})

        # resume: start again returns same attempt with saved answers
        r = await c.post(f"/api/exams/{exam_id}/start", headers=H)
        assert r.json()["attempt_id"] == aid
        assert len(r.json()["answers"]) == 3
        print("  resume OK, 3 answers persisted in redis")

        # submit: q0=B wrong(-1), q1=A correct(+4), q2=A correct(+4) => 7
        r = await c.post(f"/api/attempts/{aid}/submit", headers=H)
        assert r.status_code == 200, r.text
        res = r.json()
        assert res["correct"] == 2 and res["wrong"] == 1 and res["unattempted"] == 2, res
        assert res["score"] == 7.0, res
        print(f"  submitted: score={res['score']} correct={res['correct']} wrong={res['wrong']}")

        # idempotent re-submit
        r2 = await c.post(f"/api/attempts/{aid}/submit", headers=H)
        assert r2.json()["score"] == 7.0
        # writes after submit rejected
        r = await c.put(f"/api/attempts/{aid}/answers", headers=H,
                        json={"answers": [{"question_id": qids[3], "choice": "A", "state": "answered", "version": 1}]})
        assert list(r.json()["results"].values())[0] == "CLOSED"
        print("  post-submit writes rejected, idempotent submit OK")

    print("ALL TESTS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
