"""Seed an admin, some candidates, and a demo exam. Idempotent-ish: run once
against a fresh DB. Usage: python seed.py"""
import asyncio
import random
from datetime import datetime, timedelta

from app.db import engine, Base, SessionLocal
from app.models import User, Exam, Question, Centre
from app.security import hash_password

SUBJECTS = {
    "Physics": [
        ("A body moves with constant velocity. Net force on it is:",
         {"A": "Zero", "B": "Constant non-zero", "C": "Increasing", "D": "Decreasing"}, "A"),
        ("SI unit of electric charge is:",
         {"A": "Ampere", "B": "Coulomb", "C": "Volt", "D": "Ohm"}, "B"),
    ],
    "Chemistry": [
        ("The pH of a neutral solution at 25 C is:",
         {"A": "0", "B": "7", "C": "14", "D": "1"}, "B"),
        ("Which gas is most abundant in Earth's atmosphere?",
         {"A": "Oxygen", "B": "Carbon dioxide", "C": "Nitrogen", "D": "Argon"}, "C"),
    ],
    "Biology": [
        ("The powerhouse of the cell is the:",
         {"A": "Nucleus", "B": "Ribosome", "C": "Mitochondria", "D": "Golgi body"}, "C"),
        ("Human beings have how many pairs of chromosomes?",
         {"A": "21", "B": "22", "C": "23", "D": "24"}, "C"),
    ],
}


async def main():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with SessionLocal() as db:
        # centres
        blr = Centre(code="BLR01", name="Bengaluru Centre 1", city="Bengaluru", capacity=300)
        de = Centre(code="DEL01", name="Delhi Centre 1", city="New Delhi", capacity=300)
        db.add_all([blr, de])
        await db.flush()

        # staff
        db.add_all([
            User(roll_no="admin", name="Exam Controller", role="admin",
                 password_hash=hash_password("admin123")),
            User(roll_no="inv_blr", name="R. Sharma (Bengaluru)", role="invigilator",
                 centre_id=blr.id, password_hash=hash_password("invig123")),
            User(roll_no="inv_del", name="P. Nair (Delhi)", role="invigilator",
                 centre_id=de.id, password_hash=hash_password("invig123")),
            User(roll_no="support1", name="Helpdesk Agent 1", role="support",
                 password_hash=hash_password("support123")),
        ])

        # candidates, split across the two centres; every 10th gets compensatory time
        for i in range(1, 51):
            db.add(User(
                roll_no=f"NEET{i:04d}", name=f"Candidate {i}", role="candidate",
                centre_id=(blr.id if i <= 30 else de.id),
                extra_time_minutes=(20 if i % 10 == 0 else 0),
                password_hash=hash_password("test123"),
            ))

        now = datetime.utcnow()
        exam = Exam(
            title="NEET Mock Test 2026 — Full Syllabus",
            duration_minutes=180,
            marks_correct=4.0, marks_wrong=-1.0,
            window_start=now - timedelta(minutes=5),
            window_end=now + timedelta(hours=6),
            shuffle_questions=True, published=True,
        )
        db.add(exam)
        await db.flush()

        # build a 45-question paper by repeating the bank
        qcount = 0
        while qcount < 45:
            for section, items in SUBJECTS.items():
                for text, opts, correct in items:
                    db.add(Question(exam_id=exam.id, section=section,
                                    text=f"Q{qcount+1}. {text}", options=opts,
                                    correct_option=correct))
                    qcount += 1
                    if qcount >= 45:
                        break
                if qcount >= 45:
                    break
        await db.commit()
        print(f"""
Seeded {qcount} questions, exam_id={exam.id}

  ROLE          LOGIN       PASSWORD     SCOPE
  admin         admin       admin123     national
  invigilator   inv_blr     invig123     BLR01 (candidates 1-30)
  invigilator   inv_del     invig123     DEL01 (candidates 31-50)
  support       support1    support123   national, read-only on exam state
  candidate     NEET0001..NEET0050  test123
                (every 10th candidate has +20 min compensatory time)
""")


if __name__ == "__main__":
    asyncio.run(main())
