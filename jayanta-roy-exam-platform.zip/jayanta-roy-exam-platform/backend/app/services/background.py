"""Two background loops that run inside each API pod (in production these move
to a dedicated worker deployment consuming a Kafka topic — same logic).

1. flusher      : drains dirty answer hashes from Redis → Postgres (audit copy)
2. sweeper      : auto-submits attempts whose deadline passed (crashed clients)
"""
import asyncio
import json
import logging
import time

from sqlalchemy.dialects.postgresql import insert as pg_insert

from ..config import settings
from ..db import SessionLocal
from ..models import AnswerRecord, Attempt
from ..redis_client import get_redis, k_dirty, k_active

log = logging.getLogger("background")


async def flusher_loop():
    r = get_redis()
    while True:
        try:
            dirty = await r.spop(k_dirty(), settings.FLUSH_BATCH_SIZE)
            if dirty:
                if isinstance(dirty, str):
                    dirty = [dirty]
                await _flush_keys(r, dirty)
        except Exception:
            log.exception("flusher iteration failed")
        await asyncio.sleep(settings.FLUSH_INTERVAL_SECONDS)


async def _flush_keys(r, answer_keys: list[str]):
    rows = []
    for key in answer_keys:
        # key format: att:{<attempt_id>}:ans
        attempt_id = key.split("{")[1].split("}")[0]
        raw = await r.hgetall(key)
        for qid, payload in raw.items():
            a = json.loads(payload)
            rows.append({
                "attempt_id": attempt_id,
                "question_id": int(qid),
                "choice": a.get("choice"),
                "state": a.get("state", "answered"),
                "version": int(a.get("v", 0)),
            })
    if not rows:
        return
    async with SessionLocal() as db:
        stmt = pg_insert(AnswerRecord).values(rows)
        stmt = stmt.on_conflict_do_update(
            constraint="one_answer_per_question",
            set_={
                "choice": stmt.excluded.choice,
                "state": stmt.excluded.state,
                "version": stmt.excluded.version,
            },
            where=(AnswerRecord.version < stmt.excluded.version),
        )
        await db.execute(stmt)
        await db.commit()
    log.info("flushed %d answer rows from %d attempts", len(rows), len(answer_keys))


async def sweeper_loop():
    from .attempts import submit_attempt  # avoid circular import
    r = get_redis()
    while True:
        try:
            expired = await r.zrangebyscore(
                k_active(), 0, time.time() - settings.DEADLINE_GRACE_SECONDS, start=0, num=200
            )
            for attempt_id in expired:
                # claim it so only one pod processes it
                removed = await r.zrem(k_active(), attempt_id)
                if not removed:
                    continue
                async with SessionLocal() as db:
                    attempt = await db.get(Attempt, attempt_id)
                    if attempt and attempt.status == "active":
                        await submit_attempt(db, attempt_id, user_id=None, auto=True)
                        log.info("auto-submitted %s", attempt_id)
        except Exception:
            log.exception("sweeper iteration failed")
        await asyncio.sleep(settings.AUTOSUBMIT_SWEEP_SECONDS)
