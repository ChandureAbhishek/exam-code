"""Privileged operations on live candidate sessions.

THE COHERENCE TRAP
==================
An attempt's deadline lives in THREE places at once:
  1. Postgres  `attempts.deadline`     — the durable record
  2. Redis     meta hash `deadline`    — what the Lua answer-save script enforces
  3. Redis     ZSET `active_attempts`  — what the auto-submit sweeper reads

Update only Postgres and the candidate keeps getting rejected at the old deadline
AND gets auto-submitted early — the grant silently does nothing, and you find out
from a candidate crying at the helpdesk. Every function here updates all three,
in the order that fails safe.
"""
import time
from datetime import datetime, timedelta

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import Attempt, User
from ..redis_client import get_redis, k_attempt, k_answers, k_active
from .attempts import submit_attempt


async def grant_extra_time(db: AsyncSession, attempt_id: str, minutes: int) -> dict:
    """Extend a live attempt. Used for technical disruption (power cut, machine
    swap) and compensatory time. Returns before/after for the audit row."""
    if not (1 <= minutes <= 180):
        raise HTTPException(400, "Extra time must be between 1 and 180 minutes")

    attempt = await db.get(Attempt, attempt_id)
    if not attempt:
        raise HTTPException(404, "Attempt not found")
    if attempt.status != "active":
        raise HTTPException(409, "Attempt is already submitted — cannot extend")

    before = {"deadline": attempt.deadline.isoformat()}
    new_deadline = attempt.deadline + timedelta(minutes=minutes)

    # 1. Durable record first.
    attempt.deadline = new_deadline
    await db.flush()

    # 2 & 3. Redis meta + sweeper ZSET, atomically together.
    r = get_redis()
    ts = new_deadline.timestamp()
    pipe = r.pipeline()
    pipe.hset(k_attempt(attempt_id), "deadline", ts)
    pipe.zadd(k_active(), {attempt_id: ts})
    await pipe.execute()

    return {"before": before, "after": {"deadline": new_deadline.isoformat(),
                                        "granted_minutes": minutes}}


async def force_submit(db: AsyncSession, attempt_id: str) -> dict:
    """Invigilator ends a candidate's exam early — malpractice, medical
    emergency, or hall closing. The submission is scored normally; the audit row
    records who did it and why."""
    attempt = await db.get(Attempt, attempt_id)
    if not attempt:
        raise HTTPException(404, "Attempt not found")
    before = {"status": attempt.status}
    result = await submit_attempt(db, attempt_id, user_id=None, auto=False)
    attempt.status = "force_submitted"
    await db.flush()
    return {"before": before, "after": {"status": "force_submitted", "result": result}}


async def reopen_attempt(db: AsyncSession, attempt_id: str, minutes: int) -> dict:
    """Undo an erroneous submission (e.g. a candidate's machine crashed and the
    sweeper auto-submitted them while they were still in the hall).

    Answers are NOT touched — they are still in Redis and Postgres. We only
    reopen the window. This is the highest-privilege action in the system:
    admin-only, reason mandatory, and it is deliberately loud in the audit log."""
    attempt = await db.get(Attempt, attempt_id)
    if not attempt:
        raise HTTPException(404, "Attempt not found")
    if attempt.status == "active":
        raise HTTPException(409, "Attempt is already active")

    before = {"status": attempt.status, "submitted_at":
              attempt.submitted_at.isoformat() if attempt.submitted_at else None}

    new_deadline = datetime.utcnow() + timedelta(minutes=minutes)
    attempt.status = "active"
    attempt.submitted_at = None
    attempt.deadline = new_deadline
    await db.flush()

    r = get_redis()
    ts = new_deadline.timestamp()
    pipe = r.pipeline()
    pipe.hset(k_attempt(attempt_id), mapping={
        "user_id": attempt.user_id, "exam_id": attempt.exam_id,
        "deadline": ts, "status": "active",
    })
    pipe.expire(k_attempt(attempt_id), 24 * 3600)
    pipe.zadd(k_active(), {attempt_id: ts})
    await pipe.execute()

    return {"before": before, "after": {"status": "active",
                                        "deadline": new_deadline.isoformat()}}


# ---------------------------------------------------------------- diagnostics
async def session_diagnostics(db: AsyncSession, attempt: Attempt) -> dict:
    """What support and invigilators are allowed to SEE.

    Deliberately returns metadata only — counts and timestamps. It never returns
    the candidate's chosen options and never touches `correct_option`. A support
    agent can tell you 'your last save was 4 seconds ago, 112 answers are safely
    recorded' without ever learning what you answered.
    """
    r = get_redis()
    meta = await r.hgetall(k_attempt(attempt.id))
    raw = await r.hgetall(k_answers(attempt.id))

    last_save = 0.0
    answered = 0
    for payload in raw.values():
        import json
        a = json.loads(payload)
        last_save = max(last_save, float(a.get("ts", 0)))
        if a.get("choice") and a.get("state") in ("answered", "marked_answered"):
            answered += 1

    now = time.time()
    deadline = float(meta["deadline"]) if meta.get("deadline") else attempt.deadline.timestamp()
    return {
        "attempt_id": attempt.id,
        "status": attempt.status,
        "session_in_redis": bool(meta),
        "questions_saved": len(raw),
        "questions_answered": answered,
        "last_save_at": last_save or None,
        "seconds_since_last_save": round(now - last_save, 1) if last_save else None,
        # A live session that hasn't saved in 2 minutes is probably a
        # disconnected candidate — this is the number invigilators watch.
        "likely_disconnected": bool(last_save and (now - last_save) > 120
                                    and attempt.status == "active"),
        "time_remaining_seconds": max(0, round(deadline - now)),
        "started_at": attempt.started_at.isoformat(),
        "deadline": datetime.utcfromtimestamp(deadline).isoformat(),
    }


async def centre_roster(db: AsyncSession, exam_id: int, centre_id: int) -> list[dict]:
    """Live roster for an invigilator's hall. One Redis pipeline for all
    candidates — not N round-trips, because this polls every few seconds."""
    users = (await db.execute(
        select(User).where(User.centre_id == centre_id, User.role == "candidate")
    )).scalars().all()
    if not users:
        return []

    uid_map = {u.id: u for u in users}
    attempts = (await db.execute(
        select(Attempt).where(Attempt.exam_id == exam_id,
                              Attempt.user_id.in_(list(uid_map.keys())))
    )).scalars().all()
    by_user = {a.user_id: a for a in attempts}

    r = get_redis()
    pipe = r.pipeline()
    for a in attempts:
        pipe.hgetall(k_answers(a.id))
    hashes = await pipe.execute() if attempts else []
    ans_by_attempt = {a.id: h for a, h in zip(attempts, hashes)}

    now = time.time()
    out = []
    for u in users:
        a = by_user.get(u.id)
        row = {
            "user_id": u.id, "roll_no": u.roll_no, "name": u.name,
            "extra_time_minutes": u.extra_time_minutes,
            "attempt_id": a.id if a else None,
            "status": a.status if a else "not_started",
            "answered": 0, "seconds_since_last_save": None,
            "likely_disconnected": False, "time_remaining_seconds": None,
        }
        if a:
            raw = ans_by_attempt.get(a.id) or {}
            import json
            last = 0.0
            answered = 0
            for payload in raw.values():
                d = json.loads(payload)
                last = max(last, float(d.get("ts", 0)))
                if d.get("choice") and d.get("state") in ("answered", "marked_answered"):
                    answered += 1
            row["answered"] = answered
            row["seconds_since_last_save"] = round(now - last, 1) if last else None
            row["likely_disconnected"] = bool(
                last and (now - last) > 120 and a.status == "active")
            row["time_remaining_seconds"] = max(0, round(a.deadline.timestamp() - now))
        out.append(row)
    return out
