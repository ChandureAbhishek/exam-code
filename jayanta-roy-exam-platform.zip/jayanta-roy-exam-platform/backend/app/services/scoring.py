import json

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import Attempt, Exam, Question, Result
from ..redis_client import get_redis, k_answers


async def compute_and_store(db: AsyncSession, attempt: Attempt, reuse: bool = False) -> dict:
    """Score from the Redis answer hash (authoritative at submit time).
    The flusher independently persists the same answers for audit."""
    existing = await db.get(Result, attempt.id)
    if existing and reuse:
        return _as_dict(existing)

    exam = await db.get(Exam, attempt.exam_id)
    key = {
        q.id: q.correct_option
        for q in (await db.execute(select(Question).where(Question.exam_id == exam.id))).scalars()
    }

    r = get_redis()
    raw = await r.hgetall(k_answers(attempt.id))

    correct = wrong = 0
    answered_ids = set()
    for qid, payload in raw.items():
        a = json.loads(payload)
        if a.get("choice") and a.get("state") in ("answered", "marked_answered"):
            answered_ids.add(int(qid))
            if key.get(int(qid)) == a["choice"]:
                correct += 1
            else:
                wrong += 1

    unattempted = len(key) - len(answered_ids)
    score = correct * exam.marks_correct + wrong * exam.marks_wrong

    if existing:
        existing.score, existing.correct, existing.wrong, existing.unattempted = score, correct, wrong, unattempted
        result = existing
    else:
        result = Result(
            attempt_id=attempt.id, user_id=attempt.user_id, exam_id=exam.id,
            score=score, correct=correct, wrong=wrong, unattempted=unattempted,
        )
        db.add(result)
    await db.flush()
    return _as_dict(result)


def _as_dict(res: Result) -> dict:
    return {
        "attempt_id": res.attempt_id,
        "score": res.score,
        "correct": res.correct,
        "wrong": res.wrong,
        "unattempted": res.unattempted,
    }
