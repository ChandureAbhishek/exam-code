"""The hot path of the whole platform.

Everything a candidate does during the exam (start, save answer, fetch state,
submit) touches ONLY Redis. Postgres is written asynchronously by the flusher
and synchronously only at the two rare moments that matter: attempt creation
and final submission. This is what makes the design horizontally scalable —
app pods are stateless, Redis absorbs the write storm.
"""
import json
import random
import time
from datetime import datetime, timedelta

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import settings
from ..models import Attempt, Exam, Question
from ..redis_client import get_redis, k_attempt, k_answers, k_dirty, k_active, k_paper


# ---------------------------------------------------------------- paper cache
async def get_paper(db: AsyncSession, exam_id: int) -> list[dict]:
    """Question paper WITHOUT correct answers, cached in Redis.
    In production this JSON blob is what you push to a CDN as an encrypted
    package before the exam window opens."""
    r = get_redis()
    cached = await r.get(k_paper(exam_id))
    if cached:
        return json.loads(cached)

    rows = (await db.execute(select(Question).where(Question.exam_id == exam_id))).scalars().all()
    if not rows:
        raise HTTPException(404, "Exam has no questions")
    paper = [
        {"id": q.id, "section": q.section, "text": q.text, "options": q.options}
        for q in rows
    ]
    await r.set(k_paper(exam_id), json.dumps(paper), ex=6 * 3600)
    return paper


# ---------------------------------------------------------------- start / resume
async def start_attempt(db: AsyncSession, user_id: int, exam_id: int) -> dict:
    exam = await db.get(Exam, exam_id)
    if not exam or not exam.published:
        raise HTTPException(404, "Exam not found")

    now = datetime.utcnow()
    if not (exam.window_start <= now <= exam.window_end):
        raise HTTPException(403, "Exam window is closed")

    # Resume path: one attempt per candidate per exam, enforced by a DB
    # unique constraint (the source of truth) — never by client state.
    existing = (
        await db.execute(
            select(Attempt).where(Attempt.user_id == user_id, Attempt.exam_id == exam_id)
        )
    ).scalar_one_or_none()

    if existing:
        if existing.status != "active":
            raise HTTPException(409, "Exam already submitted")
        return await load_state(db, existing)

    # Deadline = start + duration + any compensatory time (PwD / scribe
    # candidates). Server decides; the client clock is NEVER trusted.
    # NOTE: compensatory time deliberately overrides the hard window end —
    # capping it at window_end would silently cancel the accommodation for
    # anyone starting late, which is exactly the bug that ends up in court.
    from ..models import User as _User
    candidate = await db.get(_User, user_id)
    extra = candidate.extra_time_minutes if candidate else 0
    deadline = min(
        now + timedelta(minutes=exam.duration_minutes), exam.window_end
    ) + timedelta(minutes=extra)

    paper = await get_paper(db, exam_id)
    order = [q["id"] for q in paper]
    if exam.shuffle_questions:
        # Deterministic per-candidate shuffle: same order on resume.
        rnd = random.Random(f"{exam_id}:{user_id}")
        rnd.shuffle(order)

    attempt = Attempt(
        user_id=user_id, exam_id=exam_id,
        started_at=now, deadline=deadline, question_order=order,
    )
    db.add(attempt)
    await db.commit()

    r = get_redis()
    pipe = r.pipeline()
    pipe.hset(k_attempt(attempt.id), mapping={
        "user_id": user_id, "exam_id": exam_id,
        "deadline": deadline.timestamp(), "status": "active",
    })
    pipe.expire(k_attempt(attempt.id), 24 * 3600)
    pipe.zadd(k_active(), {attempt.id: deadline.timestamp()})
    await pipe.execute()

    return await load_state(db, attempt)


async def load_state(db: AsyncSession, attempt: Attempt) -> dict:
    """Everything the client needs to render/resume the exam in one call."""
    paper = await get_paper(db, attempt.exam_id)
    by_id = {q["id"]: q for q in paper}
    r = get_redis()
    raw = await r.hgetall(k_answers(attempt.id))
    answers = {int(qid): json.loads(v) for qid, v in raw.items()}

    return {
        "attempt_id": attempt.id,
        "exam_id": attempt.exam_id,
        "server_time": time.time(),
        "deadline": attempt.deadline.timestamp(),
        "question_order": attempt.question_order,
        "questions": [by_id[qid] for qid in attempt.question_order if qid in by_id],
        "answers": answers,
        "status": attempt.status,
    }


# ---------------------------------------------------------------- answer writes
SAVE_LUA = """
-- KEYS[1] answers hash  KEYS[2] meta hash  KEYS[3] dirty set
-- ARGV[1] question_id  ARGV[2] payload json  ARGV[3] version  ARGV[4] now  ARGV[5] grace
local deadline = tonumber(redis.call('HGET', KEYS[2], 'deadline'))
local status   = redis.call('HGET', KEYS[2], 'status')
if not deadline or status ~= 'active' then return 'CLOSED' end
if tonumber(ARGV[4]) > deadline + tonumber(ARGV[5]) then return 'EXPIRED' end
local cur = redis.call('HGET', KEYS[1], ARGV[1])
if cur then
  local curv = cjson.decode(cur)['v']
  if curv and tonumber(curv) >= tonumber(ARGV[3]) then return 'STALE' end
end
redis.call('HSET', KEYS[1], ARGV[1], ARGV[2])
redis.call('EXPIRE', KEYS[1], 86400)
redis.call('SADD', KEYS[3], KEYS[1])
return 'OK'
"""


async def save_answers(attempt_id: str, user_id: int, answers: list) -> dict:
    """Batch, idempotent, version-guarded write. Executed as a Lua script so
    the deadline check + version check + write are atomic per question."""
    r = get_redis()
    meta = await r.hgetall(k_attempt(attempt_id))
    if not meta:
        raise HTTPException(404, "Attempt not found or expired")
    if int(meta["user_id"]) != user_id:
        raise HTTPException(403, "Not your attempt")

    now = time.time()
    results = {}
    for a in answers:
        payload = json.dumps({"choice": a.choice, "state": a.state, "v": a.version, "ts": now})
        res = await r.eval(
            SAVE_LUA, 3,
            k_answers(attempt_id), k_attempt(attempt_id), k_dirty(),
            a.question_id, payload, a.version, now, settings.DEADLINE_GRACE_SECONDS,
        )
        results[a.question_id] = res
        if res in ("CLOSED", "EXPIRED"):
            break
    return {"server_time": now, "results": results}


# ---------------------------------------------------------------- submission
async def submit_attempt(db: AsyncSession, attempt_id: str, user_id: int | None, auto: bool = False) -> dict:
    from .scoring import compute_and_store  # local import to avoid cycle

    attempt = await db.get(Attempt, attempt_id)
    if not attempt:
        raise HTTPException(404, "Attempt not found")
    if user_id is not None and attempt.user_id != user_id:
        raise HTTPException(403, "Not your attempt")
    if attempt.status != "active":
        # Idempotent: double-submit returns the stored result.
        return await compute_and_store(db, attempt, reuse=True)

    r = get_redis()
    # Mark closed in Redis FIRST so racing answer writes are rejected.
    await r.hset(k_attempt(attempt_id), "status", "closed")
    await r.zrem(k_active(), attempt_id)

    attempt.status = "auto_submitted" if auto else "submitted"
    attempt.submitted_at = datetime.utcnow()
    result = await compute_and_store(db, attempt)
    await db.commit()
    return result
