"""Role-based access control + mandatory audit logging.

DESIGN PRINCIPLE — SEPARATION OF DUTIES
=======================================
The threat model for a high-stakes exam is not primarily an outside attacker.
It is a trusted insider: a support agent bribed to "fix" a score, an invigilator
quietly gifting a relative extra time. So permissions are deliberately narrow
and asymmetric:

  ADMIN        Authors exams, manages staff, reads audit. CANNOT silently alter a
               live candidate's responses either — no such endpoint exists anywhere.
  INVIGILATOR  Powerful but NARROW: only candidates in their own centre, only
               during that exam. Can grant time, force-submit, verify ID, flag
               incidents. Every one of those needs a written reason.
  SUPPORT      Broad but WEAK: can look up any candidate nationally to diagnose a
               problem, but has NO write access to any exam state. Support can
               only raise and annotate tickets, and REQUEST a time grant that an
               invigilator or admin must approve. This is the key control —
               the role with the widest reach has the least power.
  CANDIDATE    Own attempt only.

NOBODY except the scoring engine can read `correct_option`. There is no endpoint
that returns it. Support diagnostics return *metadata* about answers (how many
saved, when last saved) and never the choices themselves.
"""
import uuid
from datetime import datetime

from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from .db import get_db
from .models import AuditLog, User
from .security import current_user

ROLES = ("candidate", "invigilator", "support", "admin")

# Actions that may NEVER be performed without a written reason. Enforced centrally
# so a new endpoint can't accidentally skip it.
REASON_REQUIRED = {
    "grant_extra_time", "force_submit", "reopen_attempt",
    "mark_absent", "void_attempt",
}


def require_roles(*allowed: str):
    """Dependency factory. Usage: user = Depends(require_roles("admin","support"))

    REVOCATION: JWTs are stateless, so a token stays cryptographically valid
    until it expires — including for an account you just suspended. For STAFF we
    therefore re-check `active` against the database on every privileged request.
    Suspending a compromised invigilator has to take effect in seconds, not
    whenever their token happens to expire.

    Candidates are deliberately NOT checked here: that would put a database read
    on the 40k/sec answer-save hot path. Candidate tokens are short-lived and
    carry no privileged power.

    In production, replace the per-request DB read with a Redis revocation set
    (a single O(1) SISMEMBER) so this stays cheap under staff load too.
    """
    async def _dep(user: dict = Depends(current_user),
                   db: AsyncSession = Depends(get_db)) -> dict:
        if user["role"] not in allowed:
            raise HTTPException(
                status.HTTP_403_FORBIDDEN,
                f"Requires one of: {', '.join(allowed)}",
            )
        if user["role"] != "candidate":
            await load_staff(db, user)   # raises 403 if suspended/deleted
        return user
    return _dep


async def load_staff(db: AsyncSession, user: dict) -> User:
    row = await db.get(User, user["id"])
    if not row or not row.active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Account is disabled")
    return row


async def assert_centre_scope(db: AsyncSession, staff: dict, candidate: User):
    """An invigilator may only act on candidates seated in their own centre.
    Admin is global. Support has no write path here at all, so it never reaches
    this check."""
    if staff["role"] == "admin":
        return
    if staff["role"] != "invigilator":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Not permitted to act on candidates")
    me = await db.get(User, staff["id"])
    if me.centre_id is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Invigilator is not assigned to a centre")
    if candidate.centre_id != me.centre_id:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "Candidate is allocated to a different centre",
        )


async def audit(
    db: AsyncSession,
    actor: dict,
    action: str,
    target_type: str,
    target_id: str,
    reason: str | None = None,
    before: dict | None = None,
    after: dict | None = None,
    request: Request | None = None,
) -> AuditLog:
    """Write the audit row. Refuses to proceed if a reason-required action has
    no meaningful reason — this is a hard gate, not a lint warning."""
    if action in REASON_REQUIRED:
        if not reason or len(reason.strip()) < 10:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                f"A written reason of at least 10 characters is required for '{action}'",
            )
    row = AuditLog(
        actor_id=actor["id"],
        actor_role=actor["role"],
        action=action,
        target_type=target_type,
        target_id=str(target_id),
        reason=reason.strip() if reason else None,
        before=before,
        after=after,
        ip=(request.client.host if request and request.client else None),
    )
    db.add(row)
    await db.flush()
    return row


def new_ref(prefix: str = "INC") -> str:
    return f"{prefix}-{datetime.utcnow():%Y%m%d}-{uuid.uuid4().hex[:6].upper()}"
