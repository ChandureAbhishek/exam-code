from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_db
from ..models import Exam, Attempt, Result
from ..schemas import AnswerBatchIn, ExamOut
from ..security import current_user
from ..services import attempts as svc

router = APIRouter(prefix="/api", tags=["exam"])


@router.get("/exams", response_model=list[ExamOut])
async def list_exams(db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    rows = (await db.execute(select(Exam).where(Exam.published == True))).scalars().all()  # noqa: E712
    return rows


@router.post("/exams/{exam_id}/start")
async def start(exam_id: int, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    return await svc.start_attempt(db, user["id"], exam_id)


@router.get("/attempts/{attempt_id}/state")
async def state(attempt_id: str, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    attempt = await db.get(Attempt, attempt_id)
    if not attempt or attempt.user_id != user["id"]:
        raise HTTPException(404, "Attempt not found")
    return await svc.load_state(db, attempt)


@router.put("/attempts/{attempt_id}/answers")
async def save(attempt_id: str, body: AnswerBatchIn, user=Depends(current_user)):
    return await svc.save_answers(attempt_id, user["id"], body.answers)


@router.post("/attempts/{attempt_id}/submit")
async def submit(attempt_id: str, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    return await svc.submit_attempt(db, attempt_id, user["id"])


@router.get("/attempts/{attempt_id}/result")
async def result(attempt_id: str, db: AsyncSession = Depends(get_db), user=Depends(current_user)):
    res = await db.get(Result, attempt_id)
    if not res or res.user_id != user["id"]:
        raise HTTPException(404, "Result not available")
    return {
        "score": res.score, "correct": res.correct,
        "wrong": res.wrong, "unattempted": res.unattempted,
    }
