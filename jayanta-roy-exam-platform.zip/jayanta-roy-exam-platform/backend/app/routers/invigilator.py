"""Invigilator portal — POWERFUL but NARROW.

Every write here is (a) scoped to the invigilator's own centre, (b) requires a
written reason, (c) writes an audit row in the same transaction as the change.
If the audit write fails, the change rolls back with it. That coupling is
intentional: there is no code path that mutates a candidate's exam without a
trace.
"""
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_db
from ..models import Attempt, User, Attendance, Incident, Centre
from ..rbac import require_roles, assert_centre_scope, audit, new_ref
from ..services import ops

router = APIRouter(prefix="/api/invigilator", tags=["invigilator"])

Invigilator = require_roles("invigilator", "admin")


class ReasonedAction(BaseModel):
    reason: str = Field(min_length=10, description="Written justification (audited)")


class TimeGrant(ReasonedAction):
    minutes: int = Field(ge=1, le=180)


class AttendanceMark(BaseModel):
    user_id: int
    status: str = Field(pattern="^(present|absent)$")
    id_verified: bool = False
    seat_no: str | None = None


class IncidentIn(BaseModel):
    candidate_id: int | None = None
    exam_id: int | None = None
    category: str
    severity: str = Field(default="medium", pattern="^(low|medium|high|critical)$")
    summary: str = Field(min_length=5, max_length=300)
    detail: str = ""


async def _my_centre(db: AsyncSession, staff: dict) -> int:
    me = await db.get(User, staff["id"])
    if me.centre_id is None:
        raise HTTPException(403, "You are not assigned to a centre. Contact the exam controller.")
    return me.centre_id


async def _candidate_in_scope(db: AsyncSession, staff: dict, attempt_id: str) -> tuple[Attempt, User]:
    attempt = await db.get(Attempt, attempt_id)
    if not attempt:
        raise HTTPException(404, "Attempt not found")
    candidate = await db.get(User, attempt.user_id)
    await assert_centre_scope(db, staff, candidate)
    return attempt, candidate


# ------------------------------------------------------------------ monitoring
@router.get("/centre")
async def my_centre(db: AsyncSession = Depends(get_db), staff=Depends(Invigilator)):
    cid = await _my_centre(db, staff)
    c = await db.get(Centre, cid)
    return {"id": c.id, "code": c.code, "name": c.name, "city": c.city, "capacity": c.capacity}


@router.get("/exams/{exam_id}/roster")
async def roster(exam_id: int, db: AsyncSession = Depends(get_db), staff=Depends(Invigilator)):
    """Live hall view. Polled every few seconds by the portal."""
    cid = await _my_centre(db, staff)
    rows = await ops.centre_roster(db, exam_id, cid)
    return {
        "centre_id": cid,
        "summary": {
            "allocated": len(rows),
            "started": sum(1 for r in rows if r["status"] != "not_started"),
            "active": sum(1 for r in rows if r["status"] == "active"),
            "submitted": sum(1 for r in rows if r["status"] not in ("active", "not_started")),
            "disconnected": sum(1 for r in rows if r["likely_disconnected"]),
        },
        "candidates": rows,
    }


@router.get("/attempts/{attempt_id}/diagnostics")
async def diagnostics(attempt_id: str, db: AsyncSession = Depends(get_db), staff=Depends(Invigilator)):
    attempt, _ = await _candidate_in_scope(db, staff, attempt_id)
    return await ops.session_diagnostics(db, attempt)


# --------------------------------------------------------------- interventions
@router.post("/attempts/{attempt_id}/extra-time")
async def extra_time(attempt_id: str, body: TimeGrant, request: Request,
                     db: AsyncSession = Depends(get_db), staff=Depends(Invigilator)):
    attempt, cand = await _candidate_in_scope(db, staff, attempt_id)
    change = await ops.grant_extra_time(db, attempt_id, body.minutes)
    await audit(db, staff, "grant_extra_time", "attempt", attempt_id,
                reason=body.reason, before=change["before"], after=change["after"],
                request=request)
    await db.commit()
    return {"ok": True, "roll_no": cand.roll_no, **change["after"]}


@router.post("/attempts/{attempt_id}/force-submit")
async def force_submit(attempt_id: str, body: ReasonedAction, request: Request,
                       db: AsyncSession = Depends(get_db), staff=Depends(Invigilator)):
    attempt, cand = await _candidate_in_scope(db, staff, attempt_id)
    change = await ops.force_submit(db, attempt_id)
    await audit(db, staff, "force_submit", "attempt", attempt_id,
                reason=body.reason, before=change["before"],
                after={"status": "force_submitted"}, request=request)
    await db.commit()
    return {"ok": True, "roll_no": cand.roll_no}


@router.post("/exams/{exam_id}/attendance")
async def mark_attendance(exam_id: int, body: AttendanceMark, request: Request,
                          db: AsyncSession = Depends(get_db), staff=Depends(Invigilator)):
    """ID verification at the desk. Marking someone ABSENT is reason-required
    because it can void a candidature."""
    cand = await db.get(User, body.user_id)
    if not cand:
        raise HTTPException(404, "Candidate not found")
    await assert_centre_scope(db, staff, cand)
    cid = await _my_centre(db, staff)

    row = (await db.execute(select(Attendance).where(
        Attendance.user_id == body.user_id, Attendance.exam_id == exam_id
    ))).scalar_one_or_none()
    before = {"status": row.status, "id_verified": row.id_verified} if row else None

    if not row:
        row = Attendance(user_id=body.user_id, exam_id=exam_id, centre_id=cid)
        db.add(row)
    from datetime import datetime
    row.status = body.status
    row.id_verified = body.id_verified
    row.seat_no = body.seat_no or row.seat_no
    row.verified_by = staff["id"]
    row.verified_at = datetime.utcnow()
    await db.flush()

    await audit(db, staff, "mark_attendance", "user", str(body.user_id),
                reason=None, before=before,
                after={"status": body.status, "id_verified": body.id_verified},
                request=request)
    await db.commit()
    return {"ok": True, "roll_no": cand.roll_no, "status": body.status}


@router.post("/incidents")
async def raise_incident(body: IncidentIn, request: Request,
                         db: AsyncSession = Depends(get_db), staff=Depends(Invigilator)):
    cid = await _my_centre(db, staff)
    inc = Incident(
        ref=new_ref("HALL"), candidate_id=body.candidate_id, exam_id=body.exam_id,
        centre_id=cid, category=body.category, severity=body.severity,
        summary=body.summary, detail=body.detail,
        raised_by=staff["id"], raised_by_role=staff["role"],
    )
    db.add(inc)
    await db.flush()
    await audit(db, staff, "raise_incident", "incident", inc.ref,
                after={"severity": body.severity, "category": body.category}, request=request)
    await db.commit()
    return {"ref": inc.ref, "id": inc.id}


@router.get("/incidents")
async def my_incidents(db: AsyncSession = Depends(get_db), staff=Depends(Invigilator)):
    cid = await _my_centre(db, staff)
    rows = (await db.execute(
        select(Incident).where(Incident.centre_id == cid).order_by(Incident.created_at.desc())
    )).scalars().all()
    return [
        {"ref": i.ref, "category": i.category, "severity": i.severity, "status": i.status,
         "summary": i.summary, "created_at": i.created_at.isoformat()} for i in rows
    ]
