"""Support / helpdesk portal — BROAD but WEAK.

Support can look up any candidate in the country to diagnose a problem. In
exchange, support has **no write access to any exam state**. There is no
endpoint in this file that changes a deadline, a status, or an answer.

When a candidate on the phone needs extra time, support does not grant it —
support raises a REQUEST that an invigilator or admin must approve. The role
with the widest reach has the least power, on purpose. If a support agent is
compromised, the blast radius is "they read some metadata".
"""
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_db
from ..models import Attempt, User, Incident, Centre, Exam
from ..rbac import require_roles, audit, new_ref
from ..services import ops

router = APIRouter(prefix="/api/support", tags=["support"])

Support = require_roles("support", "admin")


class TicketIn(BaseModel):
    roll_no: str | None = None
    category: str = Field(description="login_issue|network|ui_issue|hardware|other")
    severity: str = Field(default="medium", pattern="^(low|medium|high|critical)$")
    summary: str = Field(min_length=5, max_length=300)
    detail: str = ""


class TicketUpdate(BaseModel):
    status: str = Field(pattern="^(open|escalated|resolved)$")
    note: str = Field(min_length=3)


class TimeRequest(BaseModel):
    minutes: int = Field(ge=1, le=180)
    justification: str = Field(min_length=10)


@router.get("/candidates/search")
async def search(q: str, db: AsyncSession = Depends(get_db), staff=Depends(Support)):
    """Find a candidate by roll number or name. Returns identity + placement
    only — no exam content."""
    if len(q.strip()) < 3:
        raise HTTPException(400, "Enter at least 3 characters")
    term = f"%{q.strip()}%"
    rows = (await db.execute(
        select(User).where(
            User.role == "candidate",
            or_(User.roll_no.ilike(term), User.name.ilike(term)),
        ).limit(25)
    )).scalars().all()
    out = []
    for u in rows:
        centre = await db.get(Centre, u.centre_id) if u.centre_id else None
        out.append({
            "user_id": u.id, "roll_no": u.roll_no, "name": u.name,
            "centre": {"code": centre.code, "name": centre.name, "city": centre.city}
            if centre else None,
            "extra_time_minutes": u.extra_time_minutes,
        })
    return out


@router.get("/candidates/{user_id}/sessions")
async def sessions(user_id: int, db: AsyncSession = Depends(get_db), staff=Depends(Support)):
    """Session diagnostics — the screen an agent reads off while on the call.

    Returns COUNTS and TIMESTAMPS only. It cannot show which option the
    candidate picked, and there is no code path here that reads correct_option.
    'Your answers are saving fine, last one 3 seconds ago' is answerable
    without ever seeing the answers."""
    cand = await db.get(User, user_id)
    if not cand or cand.role != "candidate":
        raise HTTPException(404, "Candidate not found")

    attempts = (await db.execute(
        select(Attempt).where(Attempt.user_id == user_id)
    )).scalars().all()

    out = []
    for a in attempts:
        exam = await db.get(Exam, a.exam_id)
        diag = await ops.session_diagnostics(db, a)
        diag["exam_title"] = exam.title if exam else None
        out.append(diag)
    return {"roll_no": cand.roll_no, "name": cand.name, "sessions": out}


@router.post("/tickets")
async def create_ticket(body: TicketIn, request: Request,
                        db: AsyncSession = Depends(get_db), staff=Depends(Support)):
    cand = None
    if body.roll_no:
        cand = (await db.execute(
            select(User).where(User.roll_no == body.roll_no)
        )).scalar_one_or_none()

    inc = Incident(
        ref=new_ref("SUP"),
        candidate_id=cand.id if cand else None,
        centre_id=cand.centre_id if cand else None,
        category=body.category, severity=body.severity,
        summary=body.summary, detail=body.detail,
        raised_by=staff["id"], raised_by_role=staff["role"],
    )
    db.add(inc)
    await db.flush()
    await audit(db, staff, "create_ticket", "incident", inc.ref,
                after={"severity": body.severity, "category": body.category}, request=request)
    await db.commit()
    return {"ref": inc.ref, "id": inc.id}


@router.get("/tickets")
async def list_tickets(status: str | None = None,
                       db: AsyncSession = Depends(get_db), staff=Depends(Support)):
    stmt = select(Incident).order_by(Incident.created_at.desc()).limit(200)
    if status:
        stmt = stmt.where(Incident.status == status)
    rows = (await db.execute(stmt)).scalars().all()
    return [{
        "id": i.id, "ref": i.ref, "category": i.category, "severity": i.severity,
        "status": i.status, "summary": i.summary, "detail": i.detail,
        "raised_by_role": i.raised_by_role, "created_at": i.created_at.isoformat(),
        "resolution": i.resolution,
    } for i in rows]


@router.patch("/tickets/{ticket_id}")
async def update_ticket(ticket_id: int, body: TicketUpdate, request: Request,
                        db: AsyncSession = Depends(get_db), staff=Depends(Support)):
    inc = await db.get(Incident, ticket_id)
    if not inc:
        raise HTTPException(404, "Ticket not found")
    before = {"status": inc.status}
    from datetime import datetime
    inc.status = body.status
    inc.resolution = ((inc.resolution or "") + f"\n[{datetime.utcnow():%Y-%m-%d %H:%M}] {body.note}").strip()
    if body.status == "resolved":
        inc.resolved_by = staff["id"]
    inc.updated_at = datetime.utcnow()
    await db.flush()
    await audit(db, staff, "update_ticket", "incident", inc.ref,
                before=before, after={"status": body.status}, request=request)
    await db.commit()
    return {"ok": True, "ref": inc.ref, "status": inc.status}


@router.post("/candidates/{user_id}/request-extra-time")
async def request_extra_time(user_id: int, body: TimeRequest, request: Request,
                             db: AsyncSession = Depends(get_db), staff=Depends(Support)):
    """Support CANNOT grant time. This raises a high-severity request routed to
    the candidate's centre, which an invigilator or admin must action. The
    approval, not this request, is what changes the exam."""
    cand = await db.get(User, user_id)
    if not cand:
        raise HTTPException(404, "Candidate not found")

    inc = Incident(
        ref=new_ref("REQ"), candidate_id=user_id, centre_id=cand.centre_id,
        category="time_request", severity="high", status="escalated",
        summary=f"Extra time requested: {body.minutes} min for {cand.roll_no}",
        detail=body.justification,
        raised_by=staff["id"], raised_by_role=staff["role"],
    )
    db.add(inc)
    await db.flush()
    await audit(db, staff, "request_extra_time", "user", str(user_id),
                reason=body.justification, after={"minutes": body.minutes},
                request=request)
    await db.commit()
    return {
        "ref": inc.ref,
        "status": "escalated",
        "message": "Request logged. An invigilator or the exam controller must approve it — "
                   "support cannot grant exam time directly.",
    }
