from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_db
from ..models import User
from ..schemas import LoginIn, TokenOut
from ..security import verify_password, make_token

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login", response_model=TokenOut)
async def login(body: LoginIn, db: AsyncSession = Depends(get_db)):
    user = (
        await db.execute(select(User).where(User.roll_no == body.roll_no))
    ).scalar_one_or_none()
    if not user or not verify_password(body.password, user.password_hash):
        # deliberately identical message for both cases
        raise HTTPException(401, "Invalid roll number or password")
    return TokenOut(
        access_token=make_token(user.id, user.role, user.name),
        role=user.role,
        name=user.name,
    )
