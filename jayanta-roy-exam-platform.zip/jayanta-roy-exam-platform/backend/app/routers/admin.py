from fastapi import APIRouter, Depends
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from ..db import get_db
from ..models import Exam, Question, Result, Attempt
from ..schemas import ExamCreate
from ..rbac import require_roles as _rr
require_admin = _rr("admin")

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.post("/exams")
async def create_exam(body: ExamCreate, db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    exam = Exam(
        title=body.title,
        duration_minutes=body.duration_minutes,
        marks_correct=body.marks_correct,
        marks_wrong=body.marks_wrong,
        window_start=body.window_start.replace(tzinfo=None),
        window_end=body.window_end.replace(tzinfo=None),
        shuffle_questions=body.shuffle_questions,
    )
    db.add(exam)
    await db.flush()
    for q in body.questions:
        db.add(Question(
            exam_id=exam.id, section=q.section, text=q.text,
            options=q.options, correct_option=q.correct_option,
        ))
    await db.commit()
    return {"exam_id": exam.id, "questions": len(body.questions)}


@router.post("/exams/{exam_id}/publish")
async def publish(exam_id: int, db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    exam = await db.get(Exam, exam_id)
    exam.published = True
    await db.commit()
    return {"published": True}


@router.get("/exams/{exam_id}/stats")
async def stats(exam_id: int, db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    total = (await db.execute(
        select(func.count()).select_from(Attempt).where(Attempt.exam_id == exam_id)
    )).scalar()
    submitted = (await db.execute(
        select(func.count()).select_from(Attempt)
        .where(Attempt.exam_id == exam_id, Attempt.status != "active")
    )).scalar()
    avg = (await db.execute(
        select(func.avg(Result.score)).where(Result.exam_id == exam_id)
    )).scalar()
    return {"attempts": total, "submitted": submitted, "avg_score": float(avg) if avg else None}


# ============================================================ staff & centres
from pydantic import BaseModel, Field
from fastapi import HTTPException, Request
from sqlalchemy import or_
from ..models import User, Centre, AuditLog, Incident, Attendance
from ..rbac import audit, require_roles
from ..security import hash_password
from ..services import ops


class CentreIn(BaseModel):
    code: str
    name: str
    city: str
    capacity: int = 250


class StaffIn(BaseModel):
    roll_no: str = Field(description="Login ID for the staff member")
    name: str
    password: str = Field(min_length=8)
    role: str = Field(pattern="^(invigilator|support|admin)$")
    centre_id: int | None = None


class ReasonedMinutes(BaseModel):
    minutes: int = Field(ge=1, le=180)
    reason: str = Field(min_length=10)


@router.post("/centres")
async def create_centre(body: CentreIn, request: Request,
                        db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    c = Centre(code=body.code, name=body.name, city=body.city, capacity=body.capacity)
    db.add(c)
    await db.flush()
    await audit(db, admin, "create_centre", "centre", str(c.id),
                after=body.model_dump(), request=request)
    await db.commit()
    return {"id": c.id, "code": c.code}


@router.get("/centres")
async def list_centres(db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    rows = (await db.execute(select(Centre))).scalars().all()
    out = []
    for c in rows:
        allocated = (await db.execute(
            select(func.count()).select_from(User)
            .where(User.centre_id == c.id, User.role == "candidate")
        )).scalar()
        out.append({"id": c.id, "code": c.code, "name": c.name, "city": c.city,
                    "capacity": c.capacity, "allocated": allocated})
    return out


@router.post("/staff")
async def create_staff(body: StaffIn, request: Request,
                       db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    """Only an admin creates staff. An invigilator MUST have a centre — an
    unscoped invigilator would be able to act on any candidate nationally,
    which defeats the whole containment model."""
    if body.role == "invigilator" and body.centre_id is None:
        raise HTTPException(400, "An invigilator must be assigned to a centre")
    exists = (await db.execute(select(User).where(User.roll_no == body.roll_no))).scalar_one_or_none()
    if exists:
        raise HTTPException(409, "That login ID is already taken")

    u = User(roll_no=body.roll_no, name=body.name, role=body.role,
             centre_id=body.centre_id, password_hash=hash_password(body.password))
    db.add(u)
    await db.flush()
    await audit(db, admin, "create_staff", "user", str(u.id),
                after={"role": body.role, "centre_id": body.centre_id}, request=request)
    await db.commit()
    return {"id": u.id, "roll_no": u.roll_no, "role": u.role}


@router.get("/staff")
async def list_staff(db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    rows = (await db.execute(
        select(User).where(User.role != "candidate")
    )).scalars().all()
    return [{"id": u.id, "roll_no": u.roll_no, "name": u.name, "role": u.role,
             "centre_id": u.centre_id, "active": u.active} for u in rows]


@router.post("/staff/{user_id}/deactivate")
async def deactivate_staff(user_id: int, request: Request,
                           db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    """Kill switch for a compromised or suspended staff account. Checked on
    every privileged request via load_staff()."""
    u = await db.get(User, user_id)
    if not u or u.role == "candidate":
        raise HTTPException(404, "Staff member not found")
    u.active = False
    await db.flush()
    await audit(db, admin, "deactivate_staff", "user", str(user_id),
                before={"active": True}, after={"active": False}, request=request)
    await db.commit()
    return {"ok": True}


# ============================================================ escalated powers
@router.post("/attempts/{attempt_id}/reopen")
async def reopen(attempt_id: str, body: ReasonedMinutes, request: Request,
                 db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    """Undo an erroneous submission. ADMIN ONLY — the single most sensitive
    action in the platform, and the loudest in the audit log."""
    change = await ops.reopen_attempt(db, attempt_id, body.minutes)
    await audit(db, admin, "reopen_attempt", "attempt", attempt_id,
                reason=body.reason, before=change["before"], after=change["after"],
                request=request)
    await db.commit()
    return {"ok": True, **change["after"]}


# ============================================================ oversight
@router.get("/audit")
async def read_audit(action: str | None = None, actor_id: int | None = None,
                     limit: int = 200,
                     db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    """The oversight screen. In a real deployment this is reviewed daily during
    exam season and every grant_extra_time is reconciled against a ticket."""
    stmt = select(AuditLog).order_by(AuditLog.at.desc()).limit(min(limit, 1000))
    if action:
        stmt = stmt.where(AuditLog.action == action)
    if actor_id:
        stmt = stmt.where(AuditLog.actor_id == actor_id)
    rows = (await db.execute(stmt)).scalars().all()
    out = []
    for a in rows:
        actor = await db.get(User, a.actor_id)
        out.append({
            "id": a.id, "at": a.at.isoformat(),
            "actor": actor.name if actor else str(a.actor_id),
            "actor_role": a.actor_role, "action": a.action,
            "target_type": a.target_type, "target_id": a.target_id,
            "reason": a.reason, "before": a.before, "after": a.after, "ip": a.ip,
        })
    return out


@router.get("/warroom/{exam_id}")
async def warroom(exam_id: int, db: AsyncSession = Depends(get_db), admin=Depends(require_admin)):
    """Single-screen national view during a live exam."""
    total = (await db.execute(select(func.count()).select_from(Attempt)
             .where(Attempt.exam_id == exam_id))).scalar()
    active = (await db.execute(select(func.count()).select_from(Attempt)
              .where(Attempt.exam_id == exam_id, Attempt.status == "active"))).scalar()
    submitted = (await db.execute(select(func.count()).select_from(Attempt)
                 .where(Attempt.exam_id == exam_id, Attempt.status != "active"))).scalar()
    open_incidents = (await db.execute(select(func.count()).select_from(Incident)
                      .where(Incident.status != "resolved"))).scalar()
    critical = (await db.execute(select(func.count()).select_from(Incident)
                .where(Incident.severity == "critical", Incident.status != "resolved"))).scalar()
    grants = (await db.execute(select(func.count()).select_from(AuditLog)
              .where(AuditLog.action == "grant_extra_time"))).scalar()

    centres = (await db.execute(select(Centre))).scalars().all()
    per_centre = []
    for c in centres:
        alloc = (await db.execute(select(func.count()).select_from(User)
                 .where(User.centre_id == c.id, User.role == "candidate"))).scalar()
        per_centre.append({"code": c.code, "name": c.name, "city": c.city, "allocated": alloc})

    return {
        "exam_id": exam_id,
        "attempts": total, "active": active, "submitted": submitted,
        "open_incidents": open_incidents, "critical_incidents": critical,
        "time_grants_issued": grants,
        "centres": per_centre,
    }
