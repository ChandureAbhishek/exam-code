from datetime import datetime
from pydantic import BaseModel, Field


class LoginIn(BaseModel):
    roll_no: str
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    name: str


class AnswerIn(BaseModel):
    """One answer mutation. `version` is a per-question monotonic counter kept
    by the client; the server only applies a write if version is strictly
    greater than what it has. This makes retries and out-of-order delivery
    safe (idempotent, last-writer-wins by intent, not by network luck)."""
    question_id: int
    choice: str | None = None
    state: str = "answered"
    version: int = Field(ge=1)


class AnswerBatchIn(BaseModel):
    answers: list[AnswerIn]


class ExamOut(BaseModel):
    id: int
    title: str
    duration_minutes: int
    window_start: datetime
    window_end: datetime
    marks_correct: float
    marks_wrong: float


class QuestionUpload(BaseModel):
    section: str = "General"
    text: str
    options: dict[str, str]
    correct_option: str


class ExamCreate(BaseModel):
    title: str
    duration_minutes: int = 180
    marks_correct: float = 4.0
    marks_wrong: float = -1.0
    window_start: datetime
    window_end: datetime
    shuffle_questions: bool = True
    questions: list[QuestionUpload] = []
