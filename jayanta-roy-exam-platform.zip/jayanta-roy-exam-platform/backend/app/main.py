import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .db import engine, Base
from .routers import auth, exam, admin, invigilator, support
from .services.background import flusher_loop, sweeper_loop

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    tasks = [asyncio.create_task(flusher_loop()), asyncio.create_task(sweeper_loop())]
    yield
    for t in tasks:
        t.cancel()


app = FastAPI(title="Exam Platform", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(exam.router)
app.include_router(admin.router)
app.include_router(invigilator.router)
app.include_router(support.router)


@app.get("/api/health")
async def health():
    return {"ok": True}
