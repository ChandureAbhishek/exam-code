import redis.asyncio as redis

from .config import settings

# One shared pool per process. In production this points at a Redis Cluster
# (sharded by attempt id) — the key naming below is already cluster-safe
# because every key for one attempt shares the same hash tag {attempt_id}.
pool = redis.ConnectionPool.from_url(settings.REDIS_URL, max_connections=100, decode_responses=True)


def get_redis() -> redis.Redis:
    return redis.Redis(connection_pool=pool)


# ---- Key naming (single source of truth) ------------------------------------
def k_attempt(attempt_id: str) -> str:
    return f"att:{{{attempt_id}}}:meta"


def k_answers(attempt_id: str) -> str:
    return f"att:{{{attempt_id}}}:ans"


def k_dirty() -> str:
    """Set of attempt ids with unflushed answers."""
    return "dirty_attempts"


def k_active() -> str:
    """ZSET attempt_id -> deadline epoch, used by the auto-submit sweeper."""
    return "active_attempts"


def k_paper(exam_id: int) -> str:
    return f"exam:{exam_id}:paper"
