import os


class Settings:
    """Central configuration. Every value can be overridden by environment
    variables so the same image runs in dev, staging and production."""

    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "postgresql+asyncpg://exam:exam@localhost:5432/examdb",
    )
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    JWT_SECRET: str = os.getenv("JWT_SECRET", "change-me-in-production")
    JWT_ALGO: str = "HS256"
    JWT_TTL_MINUTES: int = int(os.getenv("JWT_TTL_MINUTES", "240"))

    # Answer writes are buffered in Redis and flushed to Postgres in the
    # background. This is THE key pattern that lets the hot path survive
    # millions of concurrent writers.
    FLUSH_INTERVAL_SECONDS: float = float(os.getenv("FLUSH_INTERVAL_SECONDS", "3"))
    FLUSH_BATCH_SIZE: int = int(os.getenv("FLUSH_BATCH_SIZE", "500"))

    # Grace period after the deadline during which in-flight answer writes
    # are still accepted (network jitter tolerance).
    DEADLINE_GRACE_SECONDS: int = int(os.getenv("DEADLINE_GRACE_SECONDS", "10"))

    # Sweep interval for auto-submitting attempts whose deadline passed
    # (candidate crashed / closed browser and never pressed submit).
    AUTOSUBMIT_SWEEP_SECONDS: int = int(os.getenv("AUTOSUBMIT_SWEEP_SECONDS", "30"))

    CORS_ORIGINS: list = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:8080").split(",")


settings = Settings()
