import uuid
from datetime import datetime

from sqlalchemy import (
    String, Integer, Float, DateTime, ForeignKey, Text, JSON, Boolean,
    UniqueConstraint, Index,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def uid() -> str:
    return uuid.uuid4().hex


class Centre(Base):
    """A physical exam centre. Invigilators are scoped to exactly one centre;
    candidates are allocated to one. This scoping is a security control, not a
    convenience: an invigilator in Bengaluru must not be able to touch a
    candidate's session in Delhi."""
    __tablename__ = "centres"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(16), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(160))
    city: Mapped[str] = mapped_column(String(80))
    capacity: Mapped[int] = mapped_column(Integer, default=250)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    roll_no: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    password_hash: Mapped[str] = mapped_column(String(200))
    # candidate | invigilator | support | admin
    role: Mapped[str] = mapped_column(String(16), default="candidate")
    # Invigilators: the ONLY centre they may act on. Candidates: where they sit.
    # Support/admin: null (support is cross-centre by design, admin is global).
    centre_id: Mapped[int | None] = mapped_column(ForeignKey("centres.id"), nullable=True, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    # Compensatory time in minutes (PwD / scribe candidates). Applied at start.
    extra_time_minutes: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Exam(Base):
    __tablename__ = "exams"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    duration_minutes: Mapped[int] = mapped_column(Integer, default=180)
    # NEET-style marking by default; configurable per exam
    marks_correct: Mapped[float] = mapped_column(Float, default=4.0)
    marks_wrong: Mapped[float] = mapped_column(Float, default=-1.0)
    # login window: candidates may start any time inside it (staggered entry)
    window_start: Mapped[datetime] = mapped_column(DateTime)
    window_end: Mapped[datetime] = mapped_column(DateTime)
    shuffle_questions: Mapped[bool] = mapped_column(Boolean, default=True)
    published: Mapped[bool] = mapped_column(Boolean, default=False)

    questions: Mapped[list["Question"]] = relationship(back_populates="exam")


class Question(Base):
    __tablename__ = "questions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    exam_id: Mapped[int] = mapped_column(ForeignKey("exams.id"), index=True)
    section: Mapped[str] = mapped_column(String(60), default="General")
    text: Mapped[str] = mapped_column(Text)
    options: Mapped[dict] = mapped_column(JSON)          # {"A": "...", "B": "..."}
    correct_option: Mapped[str] = mapped_column(String(4))  # never sent to candidates

    exam: Mapped["Exam"] = relationship(back_populates="questions")


class Attempt(Base):
    __tablename__ = "attempts"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=uid)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    exam_id: Mapped[int] = mapped_column(ForeignKey("exams.id"), index=True)
    started_at: Mapped[datetime] = mapped_column(DateTime)
    deadline: Mapped[datetime] = mapped_column(DateTime)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="active")  # active|submitted|auto_submitted
    question_order: Mapped[list] = mapped_column(JSON)  # per-candidate shuffled order

    __table_args__ = (UniqueConstraint("user_id", "exam_id", name="one_attempt_per_exam"),)


class AnswerRecord(Base):
    """Durable copy of answers, written asynchronously by the flusher.
    The hot path never touches this table."""
    __tablename__ = "answers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    attempt_id: Mapped[str] = mapped_column(String(32), index=True)
    question_id: Mapped[int] = mapped_column(Integer)
    choice: Mapped[str | None] = mapped_column(String(4), nullable=True)
    state: Mapped[str] = mapped_column(String(20), default="answered")  # answered|marked|marked_answered|cleared
    version: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("attempt_id", "question_id", name="one_answer_per_question"),
        Index("ix_answers_attempt_q", "attempt_id", "question_id"),
    )


class Result(Base):
    __tablename__ = "results"
    attempt_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    user_id: Mapped[int] = mapped_column(Integer, index=True)
    exam_id: Mapped[int] = mapped_column(Integer, index=True)
    score: Mapped[float] = mapped_column(Float)
    correct: Mapped[int] = mapped_column(Integer)
    wrong: Mapped[int] = mapped_column(Integer)
    unattempted: Mapped[int] = mapped_column(Integer)
    computed_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Attendance(Base):
    """Invigilator marks physical presence + ID verification at the desk.
    Separate from 'logged in' — a session can be live while the person in the
    chair was never verified. That gap is exactly how impersonation happens."""
    __tablename__ = "attendance"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    exam_id: Mapped[int] = mapped_column(ForeignKey("exams.id"), index=True)
    centre_id: Mapped[int] = mapped_column(ForeignKey("centres.id"), index=True)
    status: Mapped[str] = mapped_column(String(16), default="expected")  # expected|present|absent
    id_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    verified_by: Mapped[int | None] = mapped_column(Integer, nullable=True)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    seat_no: Mapped[str | None] = mapped_column(String(16), nullable=True)

    __table_args__ = (UniqueConstraint("user_id", "exam_id", name="one_attendance_per_exam"),)


class Incident(Base):
    """Unified ticket/incident record. Raised by support (candidate called the
    helpdesk) or by an invigilator (something happened in the hall).
    Severity drives the war-room dashboard."""
    __tablename__ = "incidents"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ref: Mapped[str] = mapped_column(String(20), unique=True, index=True)
    candidate_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    exam_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    centre_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    # power_failure|network|hardware|malpractice|ui_issue|login_issue|other
    category: Mapped[str] = mapped_column(String(32))
    severity: Mapped[str] = mapped_column(String(12), default="medium")  # low|medium|high|critical
    status: Mapped[str] = mapped_column(String(16), default="open")  # open|escalated|resolved
    summary: Mapped[str] = mapped_column(String(300))
    detail: Mapped[str] = mapped_column(Text, default="")
    raised_by: Mapped[int] = mapped_column(Integer, index=True)
    raised_by_role: Mapped[str] = mapped_column(String(16))
    resolution: Mapped[str | None] = mapped_column(Text, nullable=True)
    resolved_by: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class AuditLog(Base):
    """Append-only record of every privileged action. This table is the single
    most important integrity control in the system.

    Rules enforced in code (see rbac.py):
      - No staff action that touches a candidate's exam is possible without a row here.
      - Time grants and force-submits REQUIRE a free-text reason.
      - before/after snapshots make every change reversible and provable.
    In production: revoke UPDATE/DELETE on this table from the app role, ship it
    to WORM storage, and reconcile nightly."""
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_id: Mapped[int] = mapped_column(Integer, index=True)
    actor_role: Mapped[str] = mapped_column(String(16))
    action: Mapped[str] = mapped_column(String(48), index=True)
    target_type: Mapped[str] = mapped_column(String(24))   # attempt|user|exam|incident
    target_id: Mapped[str] = mapped_column(String(48), index=True)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    before: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    after: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
