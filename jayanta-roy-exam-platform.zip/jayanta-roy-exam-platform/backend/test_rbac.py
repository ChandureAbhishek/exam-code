"""RBAC / separation-of-duties test suite.

This file exists because untested access control is worse than none — it gives
false confidence. Every assertion below is an attack that MUST fail.
"""
import asyncio
import os

os.environ["DATABASE_URL"] = "sqlite+aiosqlite:///./test_rbac.db"

import fakeredis.aioredis
from app import redis_client

_fake = fakeredis.aioredis.FakeRedis(decode_responses=True)
redis_client.get_redis = lambda: _fake

import httpx
from datetime import datetime, timedelta
from app.main import app
from app import db as dbmod
from app.db import Base
from app.models import User, Exam, Question, Centre
from app.security import hash_password

OK = lambda m: print(f"  \033[32mPASS\033[0m {m}")


async def seed():
    async with dbmod.engine.begin() as c:
        await c.run_sync(Base.metadata.drop_all)
        await c.run_sync(Base.metadata.create_all)
    async with dbmod.SessionLocal() as s:
        blr = Centre(code="BLR01", name="Bengaluru Centre 1", city="Bengaluru")
        del_ = Centre(code="DEL01", name="Delhi Centre 1", city="Delhi")
        s.add_all([blr, del_])
        await s.flush()

        s.add_all([
            User(roll_no="admin", name="Controller", role="admin",
                 password_hash=hash_password("admin123")),
            User(roll_no="inv_blr", name="Inv Bengaluru", role="invigilator",
                 centre_id=blr.id, password_hash=hash_password("pass1234")),
            User(roll_no="inv_del", name="Inv Delhi", role="invigilator",
                 centre_id=del_.id, password_hash=hash_password("pass1234")),
            User(roll_no="support1", name="Helpdesk", role="support",
                 password_hash=hash_password("pass1234")),
            User(roll_no="C0001", name="Cand BLR", role="candidate",
                 centre_id=blr.id, password_hash=hash_password("test123")),
            # PwD candidate with 20 min compensatory time
            User(roll_no="C0002", name="Cand PwD", role="candidate", centre_id=blr.id,
                 extra_time_minutes=20, password_hash=hash_password("test123")),
        ])
        now = datetime.utcnow()
        ex = Exam(title="Mock", duration_minutes=180, marks_correct=4, marks_wrong=-1,
                  window_start=now - timedelta(minutes=1), window_end=now + timedelta(hours=5),
                  shuffle_questions=False, published=True)
        s.add(ex)
        await s.flush()
        for i in range(5):
            s.add(Question(exam_id=ex.id, section="Physics", text=f"Q{i}",
                           options={"A": "a", "B": "b"}, correct_option="A"))
        await s.commit()
        return ex.id, blr.id


async def login(c, roll, pw):
    r = await c.post("/api/auth/login", json={"roll_no": roll, "password": pw})
    assert r.status_code == 200, f"login failed for {roll}: {r.text}"
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


async def main():
    exam_id, blr_id = await seed()
    tr = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=tr, base_url="http://t") as c:
        H_admin = await login(c, "admin", "admin123")
        H_blr = await login(c, "inv_blr", "pass1234")
        H_del = await login(c, "inv_del", "pass1234")
        H_sup = await login(c, "support1", "pass1234")
        H_c1 = await login(c, "C0001", "test123")
        H_c2 = await login(c, "C0002", "test123")

        print("\n-- compensatory time --")
        s1 = (await c.post(f"/api/exams/{exam_id}/start", headers=H_c1)).json()
        s2 = (await c.post(f"/api/exams/{exam_id}/start", headers=H_c2)).json()
        a1, a2 = s1["attempt_id"], s2["attempt_id"]
        delta = (s2["deadline"] - s2["server_time"]) - (s1["deadline"] - s1["server_time"])
        assert 19 * 60 < delta < 21 * 60, f"PwD extra time not applied: {delta}s"
        OK(f"PwD candidate received {round(delta/60)} min extra automatically")

        print("\n-- candidate cannot reach staff endpoints --")
        for path, H in [(f"/api/invigilator/exams/{exam_id}/roster", H_c1),
                        ("/api/support/tickets", H_c1),
                        ("/api/admin/audit", H_c1),
                        ("/api/admin/staff", H_c1)]:
            r = await c.get(path, headers=H)
            assert r.status_code == 403, f"{path} returned {r.status_code}, expected 403"
        OK("candidate blocked from invigilator, support and admin endpoints")

        print("\n-- centre scoping: Delhi invigilator cannot touch a Bengaluru candidate --")
        r = await c.post(f"/api/invigilator/attempts/{a1}/extra-time", headers=H_del,
                         json={"minutes": 30, "reason": "friend needs more time please"})
        assert r.status_code == 403, r.text
        assert "different centre" in r.text.lower()
        OK("cross-centre time grant rejected (403)")

        r = await c.post(f"/api/invigilator/attempts/{a1}/force-submit", headers=H_del,
                         json={"reason": "attempting to end a rival's exam early"})
        assert r.status_code == 403
        OK("cross-centre force-submit rejected (403)")

        print("\n-- support has NO write power over exam state --")
        r = await c.post(f"/api/invigilator/attempts/{a1}/extra-time", headers=H_sup,
                         json={"minutes": 30, "reason": "caller asked me nicely for time"})
        assert r.status_code == 403, r.text
        OK("support cannot grant extra time directly (403)")

        r = await c.post(f"/api/admin/attempts/{a1}/reopen", headers=H_sup,
                         json={"minutes": 30, "reason": "trying to reopen a submission"})
        assert r.status_code == 403
        OK("support cannot reopen a submitted attempt (403)")

        r = await c.post("/api/admin/staff", headers=H_sup, json={
            "roll_no": "rogue", "name": "Rogue", "password": "password1", "role": "admin"})
        assert r.status_code == 403
        OK("support cannot create an admin account (403)")

        print("\n-- support CAN diagnose, but sees no answer content --")
        r = await c.get("/api/support/candidates/search?q=C000", headers=H_sup)
        assert r.status_code == 200 and len(r.json()) >= 2
        uid = [x for x in r.json() if x["roll_no"] == "C0001"][0]["user_id"]
        r = await c.get(f"/api/support/candidates/{uid}/sessions", headers=H_sup)
        assert r.status_code == 200
        blob = r.text.lower()
        for leak in ("correct_option", "choice", '"a"', "correct_answer"):
            assert leak not in blob, f"support diagnostics leaked '{leak}'"
        OK("support diagnostics expose metadata only — no choices, no answer key")

        print("\n-- reason is mandatory and enforced centrally --")
        r = await c.post(f"/api/invigilator/attempts/{a1}/extra-time", headers=H_blr,
                         json={"minutes": 15, "reason": "ok"})
        assert r.status_code == 422, f"expected validation failure, got {r.status_code}"
        OK("time grant with a 2-character reason rejected")

        print("\n-- legitimate invigilator action succeeds and is audited --")
        before = (await c.get(f"/api/invigilator/attempts/{a1}/diagnostics", headers=H_blr)).json()
        r = await c.post(f"/api/invigilator/attempts/{a1}/extra-time", headers=H_blr,
                         json={"minutes": 15,
                               "reason": "UPS failure at seat 14, machine down for 15 minutes"})
        assert r.status_code == 200, r.text
        after = (await c.get(f"/api/invigilator/attempts/{a1}/diagnostics", headers=H_blr)).json()
        gained = after["time_remaining_seconds"] - before["time_remaining_seconds"]
        assert 14 * 60 < gained < 16 * 60, f"grant not reflected in live session: {gained}s"
        OK(f"grant applied coherently to Redis + Postgres (+{round(gained/60)} min live)")

        audit = (await c.get("/api/admin/audit?action=grant_extra_time", headers=H_admin)).json()
        assert len(audit) == 1, audit
        assert audit[0]["actor_role"] == "invigilator"
        assert "UPS failure" in audit[0]["reason"]
        assert audit[0]["before"] and audit[0]["after"]
        OK("audit row written with actor, reason, and before/after snapshot")

        print("\n-- support escalation path works instead of direct power --")
        r = await c.post(f"/api/support/candidates/{uid}/request-extra-time", headers=H_sup,
                         json={"minutes": 20, "justification": "candidate reports broken keyboard"})
        assert r.status_code == 200 and r.json()["status"] == "escalated"
        OK("support time request escalates rather than applying")

        print("\n-- deactivated staff lose access immediately --")
        staff = (await c.get("/api/admin/staff", headers=H_admin)).json()
        inv_id = [s for s in staff if s["roll_no"] == "inv_blr"][0]["id"]
        await c.post(f"/api/admin/staff/{inv_id}/deactivate", headers=H_admin)
        r = await c.post(f"/api/invigilator/attempts/{a1}/extra-time", headers=H_blr,
                         json={"minutes": 10, "reason": "should be blocked after deactivation"})
        assert r.status_code == 403, f"deactivated invigilator still acted: {r.status_code}"
        OK("deactivated invigilator blocked even with a valid unexpired token")

        print("\n-- admin-only escalated power --")
        await c.post(f"/api/attempts/{a2}/submit", headers=H_c2)
        r = await c.post(f"/api/admin/attempts/{a2}/reopen", headers=H_admin,
                         json={"minutes": 30, "reason": "machine crash confirmed by centre CCTV"})
        assert r.status_code == 200, r.text
        st = (await c.get(f"/api/attempts/{a2}/state", headers=H_c2)).json()
        assert st["status"] == "active"
        OK("admin reopened an erroneous submission; answers preserved")

    print("\n\033[32mALL RBAC TESTS PASSED\033[0m")


if __name__ == "__main__":
    asyncio.run(main())
