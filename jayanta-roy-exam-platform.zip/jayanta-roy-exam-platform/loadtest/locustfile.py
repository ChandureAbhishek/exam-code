"""Load test that models REAL candidate behavior, not a naive hammer.

Each simulated candidate:
  1. logs in
  2. starts the exam
  3. spends the session answering questions at human-ish intervals (batched saves)
  4. submits

Run against a seeded DB (seed.py creates NEET0001..NEET0050 — bump the range
and the seed count for bigger tests).

    pip install locust
    locust -f locustfile.py --host http://localhost:8000

Then open http://localhost:8089 and set users + spawn rate. The spawn rate is
your "thundering herd" knob — set it high to simulate everyone logging in at 9AM.
"""
import random
import itertools

from locust import HttpUser, task, between, events

# roll numbers are h001-based; give each simulated user a unique one
_counter = itertools.count(1)


class Candidate(HttpUser):
    wait_time = between(2, 6)  # think time between question saves

    def on_start(self):
        n = next(_counter)
        roll = f"NEET{((n - 1) % 50) + 1:04d}"  # cycle through seeded users
        r = self.client.post("/api/auth/login",
                             json={"roll_no": roll, "password": "test123"}, name="login")
        if r.status_code != 200:
            self.token = None
            return
        self.token = r.json()["access_token"]
        self.headers = {"Authorization": f"Bearer {self.token}"}

        # find an exam and start
        exams = self.client.get("/api/exams", headers=self.headers, name="list_exams").json()
        if not exams:
            return
        self.exam_id = exams[0]["id"]
        s = self.client.post(f"/api/exams/{self.exam_id}/start",
                             headers=self.headers, name="start").json()
        self.attempt_id = s["attempt_id"]
        self.order = s["question_order"]
        self.versions = {}
        self.answered = 0

    @task(10)
    def answer(self):
        if not getattr(self, "attempt_id", None) or self.answered >= len(self.order):
            return
        qid = self.order[self.answered]
        self.versions[qid] = self.versions.get(qid, 0) + 1
        self.client.put(f"/api/attempts/{self.attempt_id}/answers",
                        headers=self.headers, name="save_answer",
                        json={"answers": [{
                            "question_id": qid,
                            "choice": random.choice(["A", "B", "C", "D"]),
                            "state": "answered",
                            "version": self.versions[qid],
                        }]})
        self.answered += 1

    @task(1)
    def submit_and_stop(self):
        # a fraction submit and leave, mimicking staggered finishing
        if getattr(self, "attempt_id", None) and self.answered > len(self.order) * 0.6:
            self.client.post(f"/api/attempts/{self.attempt_id}/submit",
                            headers=self.headers, name="submit")
            self.attempt_id = None
