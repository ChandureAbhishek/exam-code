import { useState } from "react";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Exam from "./pages/Exam";
import Result from "./pages/Result";
import Invigilator from "./pages/Invigilator";
import Support from "./pages/Support";
import Admin from "./pages/Admin";

// Role decides the landing surface. The server enforces permissions regardless
// of what the client renders — this routing is convenience, never security.
function homeFor(role) {
  return { admin: "admin", invigilator: "invigilator", support: "support" }[role] || "dash";
}

export default function App() {
  const [screen, setScreen] = useState(
    localStorage.getItem("token") ? homeFor(localStorage.getItem("role")) : "login"
  );
  const [examState, setExamState] = useState(null);
  const [result, setResult] = useState(null);

  function logout() { localStorage.clear(); setScreen("login"); }

  switch (screen) {
    case "login":
      return <Login onLogin={(r) => setScreen(homeFor(r.role))} />;
    case "admin":
      return <Admin onLogout={logout} />;
    case "invigilator":
      return <Invigilator onLogout={logout} />;
    case "support":
      return <Support onLogout={logout} />;
    case "dash":
      return <Dashboard onLogout={logout}
               onStart={(s) => { setExamState(s); setScreen(s.status === "active" ? "exam" : "dash"); }} />;
    case "exam":
      return <Exam state={examState} onSubmit={(r) => { setResult(r); setScreen("result"); }} />;
    case "result":
      return <Result result={result} onDone={() => setScreen("dash")} />;
    default:
      return null;
  }
}
