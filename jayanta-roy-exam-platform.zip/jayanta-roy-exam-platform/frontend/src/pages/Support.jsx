import { useEffect, useState } from "react";
import { api } from "../api";
import { T, Tab, Pill, StaffShell } from "../components/staff";

export default function Support({ onLogout }) {
  const [tab, setTab] = useState("lookup");
  const [q, setQ] = useState("");
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [sessions, setSessions] = useState(null);
  const [tickets, setTickets] = useState([]);
  const [toast, setToast] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => { if (tab === "tickets") api.supTickets().then(setTickets).catch(() => {}); }, [tab, toast]);

  async function search() {
    setErr("");
    try { setResults(await api.supSearch(q)); } catch (e) { setErr(e.message); }
  }
  async function open(c) {
    setSelected(c); setSessions(null);
    try { setSessions(await api.supSessions(c.user_id)); } catch (e) { setErr(e.message); }
  }
  async function requestTime() {
    const j = prompt("Justification for the extra-time request (min 10 characters):");
    if (!j || j.trim().length < 10) return;
    const m = Number(prompt("Minutes requested:", "15"));
    if (!m) return;
    try {
      const r = await api.supRequestTime(selected.user_id, m, j.trim());
      setToast(`${r.ref} — ${r.message}`);
    } catch (e) { setToast(`Failed: ${e.message}`); }
  }
  async function resolve(t) {
    const note = prompt("Resolution note:");
    if (!note) return;
    await api.supUpdateTicket(t.id, "resolved", note);
    setToast(`${t.ref} resolved`);
  }

  return (
    <StaffShell onLogout={onLogout} title="Helpdesk console"
      subtitle="Nationwide candidate lookup and ticketing. Read-only on exam state by design — see the note below.">

      {err && <div style={{ ...T.card, background: "#fbeceb", color: "var(--danger)", marginBottom: 16 }}>{err}</div>}
      {toast && <div style={{ ...T.card, background: "#eef2f8", marginBottom: 16, fontSize: 13.5 }}>{toast}</div>}

      <div style={T.tabs}>
        <Tab active={tab === "lookup"} onClick={() => setTab("lookup")}>Candidate lookup</Tab>
        <Tab active={tab === "tickets"} onClick={() => setTab("tickets")}>Tickets</Tab>
      </div>

      {tab === "lookup" && (
        <>
          <div style={{ ...T.card, marginBottom: 16 }}>
            <div style={{ display: "flex", gap: 10 }}>
              <input style={T.input} value={q} placeholder="Roll number or name (min 3 characters)"
                     onChange={(e) => setQ(e.target.value)}
                     onKeyDown={(e) => e.key === "Enter" && search()} />
              <button style={T.btn} onClick={search}>Search</button>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1.3fr", gap: 16, alignItems: "start" }}>
            <div style={T.card}>
              <table style={T.table}>
                <thead><tr><th style={T.th}>Roll</th><th style={T.th}>Name</th><th style={T.th}>Centre</th></tr></thead>
                <tbody>
                  {results.map((r) => (
                    <tr key={r.user_id} onClick={() => open(r)} style={{ cursor: "pointer",
                        background: selected?.user_id === r.user_id ? "#eef2f8" : "transparent" }}>
                      <td style={{ ...T.td, ...T.mono, fontWeight: 600 }}>{r.roll_no}</td>
                      <td style={T.td}>{r.name}</td>
                      <td style={{ ...T.td, fontSize: 12.5, color: "var(--muted)" }}>
                        {r.centre ? `${r.centre.code} · ${r.centre.city}` : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {results.length === 0 && <div style={{ padding: 16, color: "var(--muted)", fontSize: 13.5 }}>
                No results yet. Search by roll number or name.</div>}
            </div>

            <div style={T.card}>
              {!selected && <div style={{ color: "var(--muted)", fontSize: 13.5 }}>
                Select a candidate to see live session diagnostics.</div>}
              {selected && (
                <>
                  <div style={{ fontFamily: "var(--display)", fontSize: 19, color: "var(--ink)" }}>
                    {selected.name}</div>
                  <div style={{ ...T.mono, fontSize: 12.5, color: "var(--muted)", marginBottom: 14 }}>
                    {selected.roll_no}{selected.extra_time_minutes > 0 &&
                      ` · +${selected.extra_time_minutes}m compensatory time`}</div>

                  {!sessions && <div style={{ color: "var(--muted)" }}>Loading…</div>}
                  {sessions?.sessions?.length === 0 &&
                    <div style={{ color: "var(--muted)", fontSize: 13.5 }}>No exam sessions yet.</div>}

                  {sessions?.sessions?.map((s) => (
                    <div key={s.attempt_id} style={{ border: "1px solid var(--line)", borderRadius: 8,
                                                     padding: 14, marginBottom: 10 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
                        <b style={{ fontSize: 14 }}>{s.exam_title}</b><Pill>{s.status}</Pill>
                      </div>
                      <Row k="Answers safely recorded" v={s.questions_answered} />
                      <Row k="Last save" v={s.seconds_since_last_save == null ? "—"
                             : `${Math.round(s.seconds_since_last_save)}s ago`}
                           bad={s.likely_disconnected} />
                      <Row k="Time remaining" v={`${Math.floor(s.time_remaining_seconds / 60)} min`} />
                      <Row k="Session live in cache" v={s.session_in_redis ? "Yes" : "No"} />
                      {s.likely_disconnected && (
                        <div style={{ marginTop: 10, padding: 9, background: "#fbeceb",
                                      color: "var(--danger)", borderRadius: 5, fontSize: 12.5 }}>
                          No save in over 2 minutes — the candidate is probably disconnected.
                          Ask them to check their connection; answers already recorded are safe.
                        </div>
                      )}
                    </div>
                  ))}

                  <button style={{ ...T.btnGhost, marginTop: 6 }} onClick={requestTime}>
                    Request extra time (needs approval)
                  </button>
                  <div style={{ marginTop: 12, padding: 11, background: "#f7f6f2",
                                border: "1px solid var(--line)", borderRadius: 6,
                                fontSize: 12, color: "var(--muted)", lineHeight: 1.5 }}>
                    Helpdesk accounts cannot change exam state, grant time, or view a candidate's
                    chosen answers. Time requests are routed to the centre invigilator or the exam
                    controller for approval.
                  </div>
                </>
              )}
            </div>
          </div>
        </>
      )}

      {tab === "tickets" && (
        <div style={T.card}>
          <table style={T.table}>
            <thead><tr>
              <th style={T.th}>Ref</th><th style={T.th}>Category</th><th style={T.th}>Severity</th>
              <th style={T.th}>Status</th><th style={T.th}>Summary</th><th style={T.th}>By</th>
              <th style={T.th}></th>
            </tr></thead>
            <tbody>
              {tickets.map((t) => (
                <tr key={t.id}>
                  <td style={{ ...T.td, ...T.mono }}>{t.ref}</td>
                  <td style={T.td}>{t.category}</td>
                  <td style={T.td}><Pill>{t.severity}</Pill></td>
                  <td style={T.td}><Pill>{t.status}</Pill></td>
                  <td style={T.td}>{t.summary}</td>
                  <td style={{ ...T.td, fontSize: 12.5, color: "var(--muted)" }}>{t.raised_by_role}</td>
                  <td style={T.td}>{t.status !== "resolved" &&
                    <button style={T.btnGhost} onClick={() => resolve(t)}>Resolve</button>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {tickets.length === 0 && <div style={{ padding: 20, color: "var(--muted)" }}>No tickets yet.</div>}
        </div>
      )}
    </StaffShell>
  );
}

function Row({ k, v, bad }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", fontSize: 13 }}>
      <span style={{ color: "var(--muted)" }}>{k}</span>
      <span style={{ fontFamily: "var(--mono)", fontWeight: 600,
                     color: bad ? "var(--danger)" : "var(--text)" }}>{v}</span>
    </div>
  );
}
