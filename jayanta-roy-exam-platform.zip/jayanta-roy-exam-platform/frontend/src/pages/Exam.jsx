import { useEffect, useMemo, useRef, useState } from "react";
import { api, AnswerSync } from "../api";
import Timer from "../components/Timer";
import Palette from "../components/Palette";

// Derive palette status from an answer record + whether the question was seen.
function deriveStatus(ans, visited) {
  if (!ans) return visited ? "not_answered" : "not_visited";
  const marked = ans.state === "marked" || ans.state === "marked_answered";
  const answered = !!ans.choice && (ans.state === "answered" || ans.state === "marked_answered");
  if (marked && answered) return "marked_answered";
  if (marked) return "marked";
  if (answered) return "answered";
  return "not_answered";
}

export default function Exam({ state, onSubmit }) {
  const [answers, setAnswers] = useState(state.answers || {});
  const [visited, setVisited] = useState({ [state.question_order[0]]: true });
  const [idx, setIdx] = useState(0);
  const [saveStatus, setSaveStatus] = useState("saved");
  const [confirming, setConfirming] = useState(false);
  const syncRef = useRef(null);

  const order = state.question_order;
  const qById = useMemo(() => Object.fromEntries(state.questions.map((q) => [q.id, q])), [state.questions]);
  const qid = order[idx];
  const q = qById[qid];
  const ans = answers[qid];

  useEffect(() => {
    syncRef.current = new AnswerSync(state.attempt_id, setSaveStatus);
    // seed versions from any resumed answers so new edits out-rank them
    for (const [id, a] of Object.entries(state.answers || {})) {
      if (a.v) syncRef.current.versions[id] = a.v;
    }
    const warn = (e) => { e.preventDefault(); e.returnValue = ""; };
    window.addEventListener("beforeunload", warn);
    return () => { window.removeEventListener("beforeunload", warn); syncRef.current.destroy(); };
  }, [state.attempt_id]);

  function update(qid, patch) {
    setAnswers((prev) => {
      const next = { ...prev, [qid]: { ...prev[qid], ...patch } };
      const a = next[qid];
      syncRef.current.queue(qid, a.choice ?? null, a.state || "answered");
      return next;
    });
  }

  function choose(opt) {
    const marked = ans?.state === "marked" || ans?.state === "marked_answered";
    update(qid, { choice: opt, state: marked ? "marked_answered" : "answered" });
  }
  function clearResponse() { update(qid, { choice: null, state: "cleared" }); }
  function toggleMark() {
    const isMarked = ans?.state === "marked" || ans?.state === "marked_answered";
    if (isMarked) update(qid, { state: ans?.choice ? "answered" : "cleared" });
    else update(qid, { state: ans?.choice ? "marked_answered" : "marked" });
  }

  function go(i) {
    const t = order[i];
    setVisited((v) => ({ ...v, [t]: true }));
    setIdx(i);
  }

  const statuses = useMemo(() => {
    const m = {};
    for (const id of order) m[id] = deriveStatus(answers[id], visited[id]);
    return m;
  }, [answers, visited, order]);

  const answeredCount = order.filter((id) => statuses[id] === "answered" || statuses[id] === "marked_answered").length;

  async function doSubmit(auto = false) {
    setConfirming(false);
    if (!auto) await syncRef.current.flushNow();
    const res = await api.submit(state.attempt_id);
    onSubmit(res);
  }

  return (
    <div style={{ minHeight: "100%", display: "flex", flexDirection: "column" }}>
      {/* Header */}
      <header style={SH.header}>
        <div>
          <div style={SH.examTitle}>NEET Mock Test 2026</div>
          <div style={SH.section}>{q?.section}</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <SaveIndicator status={saveStatus} />
          <Timer deadline={state.deadline} serverTime={state.server_time} onExpire={() => doSubmit(true)} />
        </div>
      </header>

      <div style={SH.body}>
        {/* Question pane */}
        <main style={SH.main}>
          <div style={SH.qmeta}>
            <span style={SH.qnum}>Question {idx + 1} <span style={{ color: "var(--muted)" }}>/ {order.length}</span></span>
            <span style={SH.marks}>+4 &nbsp;/&nbsp; −1</span>
          </div>

          <div style={SH.stem}>{q?.text}</div>

          <div style={{ display: "grid", gap: 12, marginTop: 24 }}>
            {Object.entries(q?.options || {}).map(([key, val]) => {
              const selected = ans?.choice === key;
              return (
                <button key={key} onClick={() => choose(key)} style={{
                  ...SH.option, borderColor: selected ? "var(--ink)" : "var(--line)",
                  background: selected ? "#eef2f8" : "#fff",
                  boxShadow: selected ? "inset 0 0 0 1px var(--ink)" : "none",
                }}>
                  <span style={{ ...SH.optKey, background: selected ? "var(--ink)" : "#eee",
                                 color: selected ? "#fff" : "var(--text)" }}>{key}</span>
                  <span style={{ textAlign: "left" }}>{val}</span>
                </button>
              );
            })}
          </div>

          <div style={SH.actions}>
            <button style={SH.btnGhost} onClick={clearResponse}>Clear response</button>
            <button style={SH.btnGhost} onClick={toggleMark}>
              {ans?.state?.startsWith("marked") ? "Unmark review" : "Mark for review"}
            </button>
            <div style={{ flex: 1 }} />
            <button style={SH.btnSecondary} disabled={idx === 0} onClick={() => go(idx - 1)}>Previous</button>
            <button style={SH.btnPrimary}
                    onClick={() => (idx < order.length - 1 ? go(idx + 1) : setConfirming(true))}>
              {idx < order.length - 1 ? "Save & next" : "Review & submit"}
            </button>
          </div>
        </main>

        {/* Sidebar */}
        <aside style={SH.aside}>
          <div style={SH.candBox}>
            <div style={{ fontSize: 12, color: "var(--muted)" }}>Candidate</div>
            <div style={{ fontWeight: 600 }}>{localStorage.getItem("name")}</div>
            <div style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--muted)", marginTop: 2 }}>
              Answered {answeredCount} of {order.length}
            </div>
          </div>
          <Palette order={order} statuses={statuses} current={idx} onJump={go} />
          <button style={{ ...SH.btnPrimary, width: "100%", marginTop: 22 }} onClick={() => setConfirming(true)}>
            Submit exam
          </button>
        </aside>
      </div>

      {confirming && (
        <div style={SH.modalWrap} onClick={() => setConfirming(false)}>
          <div style={SH.modal} onClick={(e) => e.stopPropagation()}>
            <h2 style={{ fontFamily: "var(--display)", margin: "0 0 8px", color: "var(--ink)" }}>Submit your exam?</h2>
            <p style={{ color: "var(--muted)", fontSize: 14, lineHeight: 1.5 }}>
              You answered <b>{answeredCount}</b> of {order.length} questions.
              Once submitted you cannot return. Unanswered questions score zero — no negative marking applies to them.
            </p>
            <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
              <button style={SH.btnSecondary} onClick={() => setConfirming(false)}>Keep working</button>
              <button style={SH.btnPrimary} onClick={() => doSubmit(false)}>Submit now</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SaveIndicator({ status }) {
  const map = {
    saved: ["#1f8a4c", "Saved"], saving: ["var(--amber)", "Saving…"],
    error: ["var(--danger)", "Retrying…"], offline: ["var(--danger)", "Offline — retrying"],
  };
  const [color, label] = map[status] || map.saved;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 7, fontSize: 12.5, color: "var(--muted)" }}>
      <span style={{ width: 8, height: 8, borderRadius: "50%", background: color }} />
      {label}
    </div>
  );
}

const SH = {
  header: { display: "flex", justifyContent: "space-between", alignItems: "center",
            padding: "14px 26px", background: "#fff", borderBottom: "1px solid var(--line)" },
  examTitle: { fontFamily: "var(--display)", fontSize: 19, fontWeight: 600, color: "var(--ink)" },
  section: { fontFamily: "var(--mono)", fontSize: 11, letterSpacing: ".12em", textTransform: "uppercase",
             color: "var(--ink-2)", marginTop: 2 },
  body: { flex: 1, display: "grid", gridTemplateColumns: "1fr 320px", gap: 0, alignItems: "start" },
  main: { padding: "30px 40px", maxWidth: 820 },
  qmeta: { display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 18 },
  qnum: { fontFamily: "var(--mono)", fontSize: 15, fontWeight: 600, color: "var(--ink)" },
  marks: { fontFamily: "var(--mono)", fontSize: 12, color: "var(--muted)" },
  stem: { fontFamily: "var(--display)", fontSize: 21, lineHeight: 1.5, color: "var(--text)" },
  option: { display: "flex", alignItems: "center", gap: 14, padding: "14px 16px", border: "1px solid",
            borderRadius: 8, fontSize: 16, fontFamily: "var(--body)", transition: "background .12s" },
  optKey: { width: 30, height: 30, borderRadius: 6, display: "grid", placeItems: "center",
            fontWeight: 700, fontFamily: "var(--mono)", flexShrink: 0 },
  actions: { display: "flex", gap: 10, marginTop: 30, alignItems: "center", flexWrap: "wrap" },
  aside: { padding: "24px 22px", borderLeft: "1px solid var(--line)", background: "#fbfaf7",
           position: "sticky", top: 0, alignSelf: "stretch", minHeight: "calc(100vh - 60px)" },
  candBox: { paddingBottom: 16, marginBottom: 18, borderBottom: "1px solid var(--line)" },
  btnPrimary: { padding: "11px 20px", background: "var(--ink)", color: "#fff", border: "none",
                borderRadius: 6, fontWeight: 600, fontSize: 14 },
  btnSecondary: { padding: "11px 18px", background: "#fff", color: "var(--ink)",
                  border: "1px solid var(--line)", borderRadius: 6, fontWeight: 600, fontSize: 14 },
  btnGhost: { padding: "11px 16px", background: "transparent", color: "var(--ink-2)",
              border: "1px solid var(--line)", borderRadius: 6, fontWeight: 500, fontSize: 13.5 },
  modalWrap: { position: "fixed", inset: 0, background: "rgba(16,35,63,.45)", display: "grid",
               placeItems: "center", padding: 20, zIndex: 50 },
  modal: { background: "#fff", borderRadius: 12, padding: 28, maxWidth: 440, width: "100%",
           boxShadow: "0 30px 80px -30px rgba(0,0,0,.5)" },
};
