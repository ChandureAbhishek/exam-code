import { useEffect, useState } from "react";
import { api } from "../api";
import { T, Tab, Stat, Pill, StaffShell } from "../components/staff";

export default function Admin({ onLogout }) {
  const [tab, setTab] = useState("warroom");
  const [wr, setWr] = useState(null);
  const [audit, setAudit] = useState([]);
  const [staff, setStaff] = useState([]);
  const [centres, setCentres] = useState([]);
  const [toast, setToast] = useState("");
  const EXAM_ID = 1;

  useEffect(() => {
    if (tab === "warroom") {
      const f = () => api.admWarroom(EXAM_ID).then(setWr).catch(() => {});
      f(); const id = setInterval(f, 5000); return () => clearInterval(id);
    }
    if (tab === "audit") api.admAudit().then(setAudit).catch(() => {});
    if (tab === "staff") { api.admStaff().then(setStaff).catch(() => {});
                           api.admCentres().then(setCentres).catch(() => {}); }
  }, [tab, toast]);

  async function addStaff() {
    const role = prompt("Role — invigilator, support or admin:");
    if (!["invigilator", "support", "admin"].includes(role)) return;
    const roll_no = prompt("Login ID:"); if (!roll_no) return;
    const name = prompt("Full name:"); if (!name) return;
    const password = prompt("Password (min 8 characters):"); if (!password) return;
    let centre_id = null;
    if (role === "invigilator") {
      centre_id = Number(prompt(`Centre ID — ${centres.map((c) => `${c.id}=${c.code}`).join(", ")}`));
      if (!centre_id) return;
    }
    try { const r = await api.admCreateStaff({ roll_no, name, password, role, centre_id });
          setToast(`Created ${r.roll_no} (${r.role})`); }
    catch (e) { setToast(`Failed: ${e.message}`); }
  }

  async function deactivate(u) {
    if (!confirm(`Suspend ${u.name}? Their access is revoked immediately.`)) return;
    await api.admDeactivate(u.id);
    setToast(`${u.name} suspended`);
  }

  return (
    <StaffShell onLogout={onLogout} title="Exam control room"
      subtitle="National oversight, staff administration and the audit trail.">

      {toast && <div style={{ ...T.card, background: "#eef2f8", marginBottom: 16, fontSize: 13.5 }}>{toast}</div>}

      <div style={T.tabs}>
        <Tab active={tab === "warroom"} onClick={() => setTab("warroom")}>War room</Tab>
        <Tab active={tab === "audit"} onClick={() => setTab("audit")}>Audit trail</Tab>
        <Tab active={tab === "staff"} onClick={() => setTab("staff")}>Staff & centres</Tab>
      </div>

      {tab === "warroom" && wr && (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(6,1fr)", gap: 12, marginBottom: 20 }}>
            <Stat label="Attempts" value={wr.attempts} />
            <Stat label="In progress" value={wr.active} tone="good" />
            <Stat label="Submitted" value={wr.submitted} />
            <Stat label="Open incidents" value={wr.open_incidents} tone={wr.open_incidents ? "warn" : "good"} />
            <Stat label="Critical" value={wr.critical_incidents} tone={wr.critical_incidents ? "bad" : "good"} />
            <Stat label="Time grants" value={wr.time_grants_issued} tone={wr.time_grants_issued > 0 ? "warn" : undefined} />
          </div>
          <div style={T.card}>
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: ".12em",
                          textTransform: "uppercase", color: "var(--muted)", marginBottom: 12 }}>
              Centres</div>
            <table style={T.table}>
              <thead><tr><th style={T.th}>Code</th><th style={T.th}>Centre</th>
                         <th style={T.th}>City</th><th style={T.th}>Allocated</th></tr></thead>
              <tbody>
                {wr.centres.map((c) => (
                  <tr key={c.code}>
                    <td style={{ ...T.td, ...T.mono, fontWeight: 600 }}>{c.code}</td>
                    <td style={T.td}>{c.name}</td>
                    <td style={T.td}>{c.city}</td>
                    <td style={{ ...T.td, ...T.mono }}>{c.allocated}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === "audit" && (
        <div style={T.card}>
          <p style={{ fontSize: 13, color: "var(--muted)", margin: "0 0 14px", lineHeight: 1.5 }}>
            Every privileged action, permanently attributed. During exam season this is reviewed
            daily and each time grant is reconciled against an incident ticket.
          </p>
          <table style={T.table}>
            <thead><tr>
              <th style={T.th}>Time</th><th style={T.th}>Actor</th><th style={T.th}>Role</th>
              <th style={T.th}>Action</th><th style={T.th}>Target</th><th style={T.th}>Reason</th>
            </tr></thead>
            <tbody>
              {audit.map((a) => (
                <tr key={a.id}>
                  <td style={{ ...T.td, ...T.mono, fontSize: 12, whiteSpace: "nowrap" }}>
                    {new Date(a.at).toLocaleString()}</td>
                  <td style={T.td}>{a.actor}</td>
                  <td style={T.td}><Pill kind="medium">{a.actor_role}</Pill></td>
                  <td style={{ ...T.td, ...T.mono, fontSize: 12.5 }}>{a.action}</td>
                  <td style={{ ...T.td, ...T.mono, fontSize: 11.5, color: "var(--muted)" }}>
                    {a.target_type}:{String(a.target_id).slice(0, 10)}</td>
                  <td style={{ ...T.td, fontSize: 12.5, maxWidth: 300 }}>{a.reason || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {audit.length === 0 && <div style={{ padding: 20, color: "var(--muted)" }}>
            No privileged actions recorded yet.</div>}
        </div>
      )}

      {tab === "staff" && (
        <>
          <div style={{ ...T.card, marginBottom: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: ".12em",
                            textTransform: "uppercase", color: "var(--muted)" }}>Staff accounts</div>
              <button style={T.btn} onClick={addStaff}>Add staff member</button>
            </div>
            <table style={T.table}>
              <thead><tr><th style={T.th}>Login</th><th style={T.th}>Name</th><th style={T.th}>Role</th>
                         <th style={T.th}>Centre</th><th style={T.th}>Status</th><th style={T.th}></th></tr></thead>
              <tbody>
                {staff.map((u) => (
                  <tr key={u.id}>
                    <td style={{ ...T.td, ...T.mono, fontWeight: 600 }}>{u.roll_no}</td>
                    <td style={T.td}>{u.name}</td>
                    <td style={T.td}><Pill kind="medium">{u.role}</Pill></td>
                    <td style={{ ...T.td, ...T.mono, fontSize: 12.5 }}>
                      {centres.find((c) => c.id === u.centre_id)?.code || "—"}</td>
                    <td style={T.td}>{u.active
                      ? <span style={{ color: "var(--st-answered)", fontSize: 12.5, fontWeight: 600 }}>Active</span>
                      : <span style={{ color: "var(--danger)", fontSize: 12.5, fontWeight: 600 }}>Suspended</span>}</td>
                    <td style={T.td}>{u.active &&
                      <button style={T.btnDanger} onClick={() => deactivate(u)}>Suspend</button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={T.card}>
            <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: ".12em",
                          textTransform: "uppercase", color: "var(--muted)", marginBottom: 12 }}>
              Centres</div>
            <table style={T.table}>
              <thead><tr><th style={T.th}>ID</th><th style={T.th}>Code</th><th style={T.th}>Name</th>
                         <th style={T.th}>City</th><th style={T.th}>Allocated / Capacity</th></tr></thead>
              <tbody>
                {centres.map((c) => (
                  <tr key={c.id}>
                    <td style={{ ...T.td, ...T.mono }}>{c.id}</td>
                    <td style={{ ...T.td, ...T.mono, fontWeight: 600 }}>{c.code}</td>
                    <td style={T.td}>{c.name}</td>
                    <td style={T.td}>{c.city}</td>
                    <td style={{ ...T.td, ...T.mono }}>{c.allocated} / {c.capacity}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </StaffShell>
  );
}
