export default function Result({ result, onDone }) {
  const total = result.correct + result.wrong + result.unattempted;
  return (
    <div style={{ minHeight: "100%", display: "grid", placeItems: "center", padding: 24 }}>
      <div style={{ width: 460, maxWidth: "100%", background: "#fff", border: "1px solid var(--line)",
                    borderRadius: 12, padding: 36, textAlign: "center",
                    boxShadow: "0 24px 60px -30px rgba(16,35,63,.35)" }}>
        <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: ".18em",
                      textTransform: "uppercase", color: "var(--ink-2)" }}>Submission received</div>
        <div style={{ fontFamily: "var(--display)", fontSize: 64, fontWeight: 600,
                      color: "var(--ink)", margin: "14px 0 2px" }}>{result.score}</div>
        <div style={{ color: "var(--muted)", fontSize: 13, marginBottom: 26 }}>Total score (+4 / −1)</div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
          <Stat label="Correct" value={result.correct} color="var(--st-answered)" />
          <Stat label="Wrong" value={result.wrong} color="var(--st-not)" />
          <Stat label="Skipped" value={result.unattempted} color="var(--muted)" />
        </div>
        <div style={{ marginTop: 22, fontSize: 13, color: "var(--muted)" }}>
          Answered {result.correct + result.wrong} of {total} questions.
        </div>
        <button onClick={onDone} style={{ marginTop: 28, padding: "12px 24px", background: "var(--ink)",
                color: "#fff", border: "none", borderRadius: 6, fontWeight: 600 }}>Back to dashboard</button>
      </div>
    </div>
  );
}

function Stat({ label, value, color }) {
  return (
    <div style={{ padding: "14px 8px", background: "#fbfaf7", border: "1px solid var(--line)", borderRadius: 8 }}>
      <div style={{ fontFamily: "var(--mono)", fontSize: 26, fontWeight: 600, color }}>{value}</div>
      <div style={{ fontSize: 11, color: "var(--muted)", textTransform: "uppercase", letterSpacing: ".05em" }}>{label}</div>
    </div>
  );
}
