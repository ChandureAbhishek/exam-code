import { useEffect, useState } from "react";
import { api } from "../api";

export default function Dashboard({ onStart, onLogout }) {
  const [exams, setExams] = useState([]);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { api.listExams().then(setExams).catch((e) => setErr(e.message)); }, []);

  async function begin(examId) {
    setBusy(true); setErr("");
    try { onStart(await api.start(examId)); }
    catch (e) { setErr(e.message); setBusy(false); }
  }

  return (
    <div style={{ maxWidth: 760, margin: "0 auto", padding: "40px 24px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
        <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: ".18em",
                      textTransform: "uppercase", color: "var(--ink-2)" }}>National Testing Portal</div>
        <button onClick={onLogout} style={{ background: "none", border: "1px solid var(--line)",
                borderRadius: 6, padding: "7px 14px", color: "var(--muted)", fontSize: 13 }}>Sign out</button>
      </div>
      <h1 style={{ fontFamily: "var(--display)", fontSize: 32, color: "var(--ink)", margin: "0 0 24px" }}>
        Available examinations
      </h1>

      {err && <div style={{ padding: 12, background: "#fbeceb", color: "var(--danger)", borderRadius: 6, marginBottom: 16 }}>{err}</div>}

      <div style={{ display: "grid", gap: 14 }}>
        {exams.map((e) => (
          <div key={e.id} style={{ background: "#fff", border: "1px solid var(--line)", borderRadius: 10,
                                   padding: 22, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontFamily: "var(--display)", fontSize: 20, fontWeight: 600, color: "var(--ink)" }}>{e.title}</div>
              <div style={{ fontFamily: "var(--mono)", fontSize: 12.5, color: "var(--muted)", marginTop: 6 }}>
                {e.duration_minutes} min · +{e.marks_correct} / {e.marks_wrong} marking
              </div>
            </div>
            <button disabled={busy} onClick={() => begin(e.id)} style={{ padding: "11px 22px",
                    background: "var(--ink)", color: "#fff", border: "none", borderRadius: 6, fontWeight: 600 }}>
              {busy ? "Loading…" : "Begin"}
            </button>
          </div>
        ))}
        {exams.length === 0 && !err && <div style={{ color: "var(--muted)" }}>No exams are open right now.</div>}
      </div>
    </div>
  );
}
