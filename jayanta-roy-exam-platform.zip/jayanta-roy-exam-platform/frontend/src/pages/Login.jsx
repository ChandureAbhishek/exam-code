import { useState } from "react";
import { api } from "../api";

export default function Login({ onLogin }) {
  const [roll, setRoll] = useState("");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setErr(""); setBusy(true);
    try {
      const r = await api.login(roll.trim(), pw);
      localStorage.setItem("token", r.access_token);
      localStorage.setItem("role", r.role);
      localStorage.setItem("name", r.name);
      onLogin(r);
    } catch (e) {
      setErr(e.message);
    } finally { setBusy(false); }
  }

  return (
    <div style={S.wrap}>
      <div style={S.card}>
        <div style={S.eyebrow}>National Testing Portal</div>
        <h1 style={S.title}>Candidate sign-in</h1>
        <p style={S.sub}>Enter the roll number and password printed on your admit card.</p>

        <label style={S.label}>Roll number</label>
        <input style={S.input} value={roll} autoFocus
               onChange={(e) => setRoll(e.target.value)}
               onKeyDown={(e) => e.key === "Enter" && document.getElementById("pw").focus()}
               placeholder="e.g. NEET0001" />

        <label style={S.label}>Password</label>
        <input id="pw" style={S.input} type="password" value={pw}
               onChange={(e) => setPw(e.target.value)}
               onKeyDown={(e) => e.key === "Enter" && submit()}
               placeholder="••••••" />

        {err && <div style={S.err}>{err}</div>}

        <button style={{ ...S.btn, opacity: busy ? 0.6 : 1 }} disabled={busy} onClick={submit}>
          {busy ? "Signing in…" : "Sign in"}
        </button>
        <div style={S.note}>Keep this window open for the full duration. Do not refresh once the exam begins.</div>
      </div>
    </div>
  );
}

const S = {
  wrap: { minHeight: "100%", display: "grid", placeItems: "center", padding: 24,
          background: "radial-gradient(1200px 600px at 50% -10%, #eef1f6, var(--paper))" },
  card: { width: 400, maxWidth: "100%", background: "var(--paper-2)", border: "1px solid var(--line)",
          borderRadius: 10, padding: "36px 32px", boxShadow: "0 24px 60px -30px rgba(16,35,63,.35)" },
  eyebrow: { fontFamily: "var(--mono)", fontSize: 11, letterSpacing: ".18em", textTransform: "uppercase",
             color: "var(--ink-2)", marginBottom: 14 },
  title: { fontFamily: "var(--display)", fontSize: 30, fontWeight: 600, margin: "0 0 6px", color: "var(--ink)" },
  sub: { color: "var(--muted)", fontSize: 14, margin: "0 0 22px", lineHeight: 1.5 },
  label: { display: "block", fontSize: 12, fontWeight: 600, color: "var(--muted)",
           textTransform: "uppercase", letterSpacing: ".05em", marginBottom: 6, marginTop: 14 },
  input: { width: "100%", padding: "11px 13px", border: "1px solid var(--line)", borderRadius: "var(--radius)",
           fontSize: 15, fontFamily: "var(--mono)", background: "#fff" },
  btn: { width: "100%", marginTop: 24, padding: "13px", background: "var(--ink)", color: "#fff",
         border: "none", borderRadius: "var(--radius)", fontSize: 15, fontWeight: 600 },
  err: { marginTop: 14, padding: "10px 12px", background: "#fbeceb", color: "var(--danger)",
         borderRadius: "var(--radius)", fontSize: 13, border: "1px solid #f1c9c5" },
  note: { marginTop: 18, fontSize: 12, color: "var(--muted)", lineHeight: 1.5, textAlign: "center" },
};
