import { useEffect, useState, useCallback } from "react";
import { api } from "../api";
import { T, Tab, Stat, Pill, StaffShell, ReasonModal } from "../components/staff";

// Live hall view. Polls every 5s — cheap because the roster is one pipelined
// Redis read, not N queries.
export default function Invigilator({ onLogout }) {
  const [centre, setCentre] = useState(null);
  const [tab, setTab] = useState("hall");
  const [roster, setRoster] = useState(null);
  const [err, setErr] = useState("");
  const [modal, setModal] = useState(null); // {kind, attempt_id, roll}
  const [incidents, setIncidents] = useState([]);
  const [toast, setToast] = useState("");
  const EXAM_ID = 1;

  const load = useCallback(async () => {
    try { setRoster(await api.invRoster(EXAM_ID)); setErr(""); }
    catch (e) { setErr(e.message); }
  }, []);

  useEffect(() => {
    api.invCentre().then(setCentre).catch((e) => setErr(e.message));
    load();
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
  }, [load]);

  useEffect(() => { if (tab === "incidents") api.invIncidents().then(setIncidents).catch(() => {}); }, [tab]);

  async function confirm(reason, minutes) {
    const m = modal; setModal(null);
    try {
      if (m.kind === "time") { await api.invExtraTime(m.attempt_id, minutes, reason);
        setToast(`Granted ${minutes} min to ${m.roll}`); }
      if (m.kind === "force") { await api.invForceSubmit(m.attempt_id, reason);
        setToast(`Ended exam for ${m.roll}`); }
      load();
    } catch (e) { setToast(`Failed: ${e.message}`); }
    setTimeout(() => setToast(""), 4000);
  }

  const s = roster?.summary;

  return (
    <StaffShell onLogout={onLogout}
      title={centre ? `${centre.name} (${centre.code})` : "Invigilator console"}
      subtitle={centre ? `${centre.city} · You can act only on candidates allocated to this centre.`
                       : "Loading centre allocation…"}
      right={<div style={{ ...T.mono, fontSize: 11.5, color: "var(--muted)" }}>
               refreshing every 5s</div>}>

      {err && <div style={{ ...T.card, background: "#fbeceb", color: "var(--danger)", marginBottom: 16 }}>{err}</div>}
      {toast && <div style={{ ...T.card, background: "#eef2f8", marginBottom: 16, fontSize: 13.5 }}>{toast}</div>}

      <div style={T.tabs}>
        <Tab active={tab === "hall"} onClick={() => setTab("hall")}>Live hall</Tab>
        <Tab active={tab === "attendance"} onClick={() => setTab("attendance")}>Attendance & ID</Tab>
        <Tab active={tab === "incidents"} onClick={() => setTab("incidents")}>Incidents</Tab>
      </div>

      {s && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 12, marginBottom: 20 }}>
          <Stat label="Allocated" value={s.allocated} />
          <Stat label="Started" value={s.started} />
          <Stat label="In progress" value={s.active} tone="good" />
          <Stat label="Submitted" value={s.submitted} />
          <Stat label="Possibly offline" value={s.disconnected} tone={s.disconnected ? "bad" : "good"} />
        </div>
      )}

      {(tab === "hall" || tab === "attendance") && (
        <div style={T.card}>
          <table style={T.table}>
            <thead><tr>
              <th style={T.th}>Roll</th><th style={T.th}>Name</th><th style={T.th}>Status</th>
              <th style={T.th}>Answered</th><th style={T.th}>Last save</th>
              <th style={T.th}>Time left</th><th style={T.th}>Actions</th>
            </tr></thead>
            <tbody>
              {(roster?.candidates || []).map((c) => (
                <tr key={c.user_id} style={c.likely_disconnected ? { background: "#fdf6f5" } : {}}>
                  <td style={{ ...T.td, ...T.mono, fontWeight: 600 }}>{c.roll_no}</td>
                  <td style={T.td}>
                    {c.name}
                    {c.extra_time_minutes > 0 &&
                      <span style={{ marginLeft: 8, fontSize: 11, color: "var(--st-marked)",
                                     fontFamily: "var(--mono)" }}>+{c.extra_time_minutes}m PwD</span>}
                  </td>
                  <td style={T.td}><Pill>{c.status}</Pill></td>
                  <td style={{ ...T.td, ...T.mono }}>{c.answered || "—"}</td>
                  <td style={{ ...T.td, ...T.mono,
                               color: c.likely_disconnected ? "var(--danger)" : "var(--muted)" }}>
                    {c.seconds_since_last_save == null ? "—"
                      : c.likely_disconnected ? `${Math.round(c.seconds_since_last_save)}s — check desk`
                      : `${Math.round(c.seconds_since_last_save)}s ago`}
                  </td>
                  <td style={{ ...T.td, ...T.mono }}>
                    {c.time_remaining_seconds == null ? "—"
                      : `${Math.floor(c.time_remaining_seconds / 60)}m`}
                  </td>
                  <td style={T.td}>
                    {c.attempt_id && c.status === "active" ? (
                      <div style={{ display: "flex", gap: 6 }}>
                        <button style={T.btnGhost}
                          onClick={() => setModal({ kind: "time", attempt_id: c.attempt_id, roll: c.roll_no })}>
                          Grant time</button>
                        <button style={T.btnDanger}
                          onClick={() => setModal({ kind: "force", attempt_id: c.attempt_id, roll: c.roll_no })}>
                          End exam</button>
                      </div>
                    ) : <span style={{ color: "var(--muted)", fontSize: 12.5 }}>—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {roster?.candidates?.length === 0 &&
            <div style={{ padding: 20, color: "var(--muted)" }}>No candidates allocated to this centre.</div>}
        </div>
      )}

      {tab === "incidents" && (
        <div style={T.card}>
          <table style={T.table}>
            <thead><tr>
              <th style={T.th}>Ref</th><th style={T.th}>Category</th><th style={T.th}>Severity</th>
              <th style={T.th}>Status</th><th style={T.th}>Summary</th><th style={T.th}>Raised</th>
            </tr></thead>
            <tbody>
              {incidents.map((i) => (
                <tr key={i.ref}>
                  <td style={{ ...T.td, ...T.mono }}>{i.ref}</td>
                  <td style={T.td}>{i.category}</td>
                  <td style={T.td}><Pill>{i.severity}</Pill></td>
                  <td style={T.td}><Pill>{i.status}</Pill></td>
                  <td style={T.td}>{i.summary}</td>
                  <td style={{ ...T.td, ...T.mono, color: "var(--muted)" }}>
                    {new Date(i.created_at).toLocaleTimeString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {incidents.length === 0 &&
            <div style={{ padding: 20, color: "var(--muted)" }}>No incidents logged at this centre.</div>}
        </div>
      )}

      <ReasonModal
        open={!!modal}
        minutesField={modal?.kind === "time"}
        title={modal?.kind === "time" ? `Grant extra time — ${modal?.roll}` : `End exam — ${modal?.roll}`}
        note={modal?.kind === "time"
          ? "Use for verified disruption only (power, hardware, network). The candidate's timer updates immediately."
          : "This submits and scores the candidate's paper straight away. It cannot be undone by you — only the exam controller can reopen an attempt."}
        onCancel={() => setModal(null)}
        onConfirm={confirm} />
    </StaffShell>
  );
}
