// Thin API layer. The important part is saveAnswer(): it never blocks the UI
// and it survives flaky networks via a client-side queue with version numbers.
const BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000";

function authHeaders() {
  const t = localStorage.getItem("token");
  return t ? { Authorization: `Bearer ${t}` } : {};
}

async function req(path, opts = {}) {
  const res = await fetch(BASE + path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...authHeaders(), ...(opts.headers || {}) },
  });
  if (res.status === 401) {
    localStorage.removeItem("token");
    location.href = "/";
    throw new Error("Session expired");
  }
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).detail || res.statusText);
  return res.json();
}

export const api = {
  login: (roll_no, password) =>
    req("/api/auth/login", { method: "POST", body: JSON.stringify({ roll_no, password }) }),
  listExams: () => req("/api/exams"),
  start: (examId) => req(`/api/exams/${examId}/start`, { method: "POST" }),
  saveAnswers: (attemptId, answers) =>
    req(`/api/attempts/${attemptId}/answers`, { method: "PUT", body: JSON.stringify({ answers }) }),
  submit: (attemptId) => req(`/api/attempts/${attemptId}/submit`, { method: "POST" }),
  result: (attemptId) => req(`/api/attempts/${attemptId}/result`),

  // ---- invigilator ----
  invCentre: () => req("/api/invigilator/centre"),
  invRoster: (examId) => req(`/api/invigilator/exams/${examId}/roster`),
  invDiag: (attemptId) => req(`/api/invigilator/attempts/${attemptId}/diagnostics`),
  invExtraTime: (attemptId, minutes, reason) =>
    req(`/api/invigilator/attempts/${attemptId}/extra-time`,
        { method: "POST", body: JSON.stringify({ minutes, reason }) }),
  invForceSubmit: (attemptId, reason) =>
    req(`/api/invigilator/attempts/${attemptId}/force-submit`,
        { method: "POST", body: JSON.stringify({ reason }) }),
  invAttendance: (examId, payload) =>
    req(`/api/invigilator/exams/${examId}/attendance`,
        { method: "POST", body: JSON.stringify(payload) }),
  invIncident: (payload) =>
    req("/api/invigilator/incidents", { method: "POST", body: JSON.stringify(payload) }),
  invIncidents: () => req("/api/invigilator/incidents"),

  // ---- support ----
  supSearch: (q) => req(`/api/support/candidates/search?q=${encodeURIComponent(q)}`),
  supSessions: (userId) => req(`/api/support/candidates/${userId}/sessions`),
  supTickets: (status) => req(`/api/support/tickets${status ? `?status=${status}` : ""}`),
  supCreateTicket: (payload) =>
    req("/api/support/tickets", { method: "POST", body: JSON.stringify(payload) }),
  supUpdateTicket: (id, status, note) =>
    req(`/api/support/tickets/${id}`, { method: "PATCH", body: JSON.stringify({ status, note }) }),
  supRequestTime: (userId, minutes, justification) =>
    req(`/api/support/candidates/${userId}/request-extra-time`,
        { method: "POST", body: JSON.stringify({ minutes, justification }) }),

  // ---- admin ----
  admWarroom: (examId) => req(`/api/admin/warroom/${examId}`),
  admAudit: (action) => req(`/api/admin/audit${action ? `?action=${action}` : ""}`),
  admStaff: () => req("/api/admin/staff"),
  admCreateStaff: (payload) =>
    req("/api/admin/staff", { method: "POST", body: JSON.stringify(payload) }),
  admDeactivate: (id) => req(`/api/admin/staff/${id}/deactivate`, { method: "POST" }),
  admCentres: () => req("/api/admin/centres"),
  admCreateCentre: (payload) =>
    req("/api/admin/centres", { method: "POST", body: JSON.stringify(payload) }),
  admCreateExam: (payload) =>
    req("/api/admin/exams", { method: "POST", body: JSON.stringify(payload) }),
  admPublish: (examId) => req(`/api/admin/exams/${examId}/publish`, { method: "POST" }),
  admReopen: (attemptId, minutes, reason) =>
    req(`/api/admin/attempts/${attemptId}/reopen`,
        { method: "POST", body: JSON.stringify({ minutes, reason }) }),
};

// ---- Resilient answer sync ---------------------------------------------------
// Answers are queued and flushed in batches. Each question carries a client-side
// version that increments on every change, so retries and reordering are safe.
export class AnswerSync {
  constructor(attemptId, onStatus) {
    this.attemptId = attemptId;
    this.onStatus = onStatus || (() => {});
    this.versions = {};           // qid -> version
    this.pending = new Map();     // qid -> {choice, state, version}
    this.inFlight = false;
    this.timer = setInterval(() => this.flush(), 2500);
    window.addEventListener("online", () => this.flush());
  }

  queue(qid, choice, state) {
    this.versions[qid] = (this.versions[qid] || 0) + 1;
    this.pending.set(qid, { question_id: qid, choice, state, version: this.versions[qid] });
    this.onStatus("saving");
    this.flush();
  }

  async flush() {
    if (this.inFlight || this.pending.size === 0) return;
    if (!navigator.onLine) { this.onStatus("offline"); return; }
    this.inFlight = true;
    const batch = [...this.pending.values()];
    try {
      await api.saveAnswers(this.attemptId, batch);
      // Only drop entries whose version wasn't superseded while in flight.
      for (const a of batch) {
        const cur = this.pending.get(a.question_id);
        if (cur && cur.version === a.version) this.pending.delete(a.question_id);
      }
      this.onStatus(this.pending.size ? "saving" : "saved");
    } catch (e) {
      this.onStatus("error"); // keep pending; will retry next tick
    } finally {
      this.inFlight = false;
    }
  }

  async flushNow() {
    // Best-effort synchronous-ish flush before submit.
    for (let i = 0; i < 5 && this.pending.size; i++) {
      await this.flush();
      if (this.pending.size) await new Promise((r) => setTimeout(r, 400));
    }
  }

  destroy() { clearInterval(this.timer); }
}
