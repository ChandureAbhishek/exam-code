import { useEffect, useState, useRef } from "react";

// Timer is anchored to the SERVER clock. On load we compute the offset between
// server_time and the local clock and apply it forever after — so changing the
// device clock or timezone can't buy extra time.
export default function Timer({ deadline, serverTime, onExpire }) {
  const offsetRef = useRef(Date.now() / 1000 - serverTime); // local - server
  const [left, setLeft] = useState(Math.max(0, deadline - serverTime));
  const firedRef = useRef(false);

  useEffect(() => {
    const id = setInterval(() => {
      const serverNow = Date.now() / 1000 - offsetRef.current;
      const remaining = Math.max(0, deadline - serverNow);
      setLeft(remaining);
      if (remaining <= 0 && !firedRef.current) {
        firedRef.current = true;
        onExpire();
      }
    }, 500);
    return () => clearInterval(id);
  }, [deadline, onExpire]);

  const h = Math.floor(left / 3600);
  const m = Math.floor((left % 3600) / 60);
  const s = Math.floor(left % 60);
  const danger = left <= 300; // last 5 minutes

  return (
    <div style={{
      fontFamily: "var(--mono)", fontSize: 22, fontWeight: 600, letterSpacing: ".04em",
      color: danger ? "var(--danger)" : "var(--ink)",
      padding: "6px 14px", border: `1px solid ${danger ? "var(--danger)" : "var(--line)"}`,
      borderRadius: 6, background: danger ? "#fbeceb" : "#fff", minWidth: 128, textAlign: "center",
    }}>
      {String(h).padStart(2, "0")}:{String(m).padStart(2, "0")}:{String(s).padStart(2, "0")}
    </div>
  );
}
