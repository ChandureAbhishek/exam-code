import React from "react";

// Shared chrome for the three staff portals. Staff tools are dense, utilitarian
// and read at a glance across a hall — different job from the candidate screen,
// so a tighter, more instrument-like treatment.
export const T = {
  shell: { minHeight: "100vh", background: "var(--paper)" },
  bar: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "12px 22px", background: "var(--ink)", color: "#fff",
  },
  brand: { fontFamily: "var(--mono)", fontSize: 11.5, letterSpacing: ".18em", textTransform: "uppercase" },
  who: { fontSize: 13, opacity: .85 },
  main: { padding: "24px 22px", maxWidth: 1280, margin: "0 auto" },
  h1: { fontFamily: "var(--display)", fontSize: 26, color: "var(--ink)", margin: "0 0 4px" },
  sub: { color: "var(--muted)", fontSize: 13.5, margin: "0 0 22px" },
  card: { background: "#fff", border: "1px solid var(--line)", borderRadius: 10, padding: 18 },
  table: { width: "100%", borderCollapse: "collapse", fontSize: 13.5 },
  th: {
    textAlign: "left", padding: "9px 10px", borderBottom: "1px solid var(--line)",
    fontFamily: "var(--mono)", fontSize: 10.5, letterSpacing: ".1em",
    textTransform: "uppercase", color: "var(--muted)", whiteSpace: "nowrap",
  },
  td: { padding: "10px", borderBottom: "1px solid #f0eee8", verticalAlign: "middle" },
  mono: { fontFamily: "var(--mono)" },
  btn: {
    padding: "7px 13px", background: "var(--ink)", color: "#fff", border: "none",
    borderRadius: 5, fontSize: 12.5, fontWeight: 600,
  },
  btnGhost: {
    padding: "7px 13px", background: "#fff", color: "var(--ink)",
    border: "1px solid var(--line)", borderRadius: 5, fontSize: 12.5, fontWeight: 600,
  },
  btnDanger: {
    padding: "7px 13px", background: "#fff", color: "var(--danger)",
    border: "1px solid #e8c4c0", borderRadius: 5, fontSize: 12.5, fontWeight: 600,
  },
  input: {
    padding: "9px 11px", border: "1px solid var(--line)", borderRadius: 5,
    fontSize: 13.5, fontFamily: "var(--body)", width: "100%",
  },
  tabs: { display: "flex", gap: 4, borderBottom: "1px solid var(--line)", marginBottom: 20 },
};

export function Tab({ active, children, onClick }) {
  return (
    <button onClick={onClick} style={{
      padding: "9px 16px", border: "none", background: "none", fontSize: 13.5,
      fontWeight: 600, cursor: "pointer",
      color: active ? "var(--ink)" : "var(--muted)",
      borderBottom: active ? "2px solid var(--ink)" : "2px solid transparent",
      marginBottom: -1,
    }}>{children}</button>
  );
}

export function Stat({ label, value, tone }) {
  const color = tone === "bad" ? "var(--danger)"
    : tone === "warn" ? "var(--amber)"
    : tone === "good" ? "var(--st-answered)" : "var(--ink)";
  return (
    <div style={{ ...T.card, padding: "14px 16px" }}>
      <div style={{ fontFamily: "var(--mono)", fontSize: 26, fontWeight: 600, color }}>{value}</div>
      <div style={{ fontSize: 11, color: "var(--muted)", textTransform: "uppercase",
                    letterSpacing: ".07em", marginTop: 2 }}>{label}</div>
    </div>
  );
}

export function Pill({ kind, children }) {
  const map = {
    active: ["#e7f3ec", "var(--st-answered)"],
    submitted: ["#eceef3", "var(--ink-2)"],
    force_submitted: ["#f3ecf8", "var(--st-marked)"],
    auto_submitted: ["#fdf1e3", "var(--amber)"],
    not_started: ["#f2f1ed", "var(--muted)"],
    critical: ["#fbeceb", "var(--danger)"],
    high: ["#fdf1e3", "var(--amber)"],
    medium: ["#eceef3", "var(--ink-2)"],
    low: ["#f2f1ed", "var(--muted)"],
    open: ["#fdf1e3", "var(--amber)"],
    escalated: ["#fbeceb", "var(--danger)"],
    resolved: ["#e7f3ec", "var(--st-answered)"],
  };
  const [bg, fg] = map[children] || map[kind] || ["#f2f1ed", "var(--muted)"];
  return (
    <span style={{ background: bg, color: fg, padding: "3px 9px", borderRadius: 20,
                   fontSize: 11.5, fontWeight: 600, fontFamily: "var(--mono)",
                   whiteSpace: "nowrap" }}>{children}</span>
  );
}

export function StaffShell({ title, subtitle, right, children, onLogout }) {
  return (
    <div style={T.shell}>
      <div style={T.bar}>
        <div style={T.brand}>National Testing Portal — Staff</div>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <span style={T.who}>{localStorage.getItem("name")} · {localStorage.getItem("role")}</span>
          <button onClick={onLogout} style={{ ...T.btnGhost, background: "transparent",
                  color: "#fff", borderColor: "rgba(255,255,255,.3)" }}>Sign out</button>
        </div>
      </div>
      <div style={T.main}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <h1 style={T.h1}>{title}</h1>
            <p style={T.sub}>{subtitle}</p>
          </div>
          {right}
        </div>
        {children}
      </div>
    </div>
  );
}

/** Modal that FORCES a written reason before a privileged action.
 *  The UI mirrors the server-side gate — the button stays disabled until the
 *  reason is real, so staff learn the norm rather than fighting a 400. */
export function ReasonModal({ open, title, note, minutesField, onCancel, onConfirm }) {
  const [reason, setReason] = React.useState("");
  const [minutes, setMinutes] = React.useState(15);
  React.useEffect(() => { if (open) { setReason(""); setMinutes(15); } }, [open]);
  if (!open) return null;
  const ok = reason.trim().length >= 10;
  return (
    <div onClick={onCancel} style={{ position: "fixed", inset: 0, background: "rgba(16,35,63,.45)",
         display: "grid", placeItems: "center", zIndex: 60, padding: 20 }}>
      <div onClick={(e) => e.stopPropagation()} style={{ ...T.card, width: 440, maxWidth: "100%" }}>
        <h3 style={{ fontFamily: "var(--display)", margin: "0 0 6px", color: "var(--ink)" }}>{title}</h3>
        <p style={{ fontSize: 13, color: "var(--muted)", lineHeight: 1.5, margin: "0 0 16px" }}>{note}</p>
        {minutesField && (
          <>
            <label style={{ fontSize: 12, fontWeight: 600, color: "var(--muted)" }}>Minutes</label>
            <input type="number" min={1} max={180} value={minutes} style={{ ...T.input, marginBottom: 14 }}
                   onChange={(e) => setMinutes(Number(e.target.value))} />
          </>
        )}
        <label style={{ fontSize: 12, fontWeight: 600, color: "var(--muted)" }}>
          Reason (recorded permanently in the audit log)
        </label>
        <textarea rows={3} value={reason} autoFocus onChange={(e) => setReason(e.target.value)}
                  placeholder="e.g. UPS failure at seat 14, machine down 15 minutes"
                  style={{ ...T.input, marginTop: 5, resize: "vertical", fontFamily: "var(--body)" }} />
        <div style={{ fontSize: 11.5, color: ok ? "var(--muted)" : "var(--amber)", marginTop: 6 }}>
          {ok ? "This entry will be attributed to you." : `${Math.max(0, 10 - reason.trim().length)} more characters required`}
        </div>
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 18 }}>
          <button style={T.btnGhost} onClick={onCancel}>Cancel</button>
          <button style={{ ...T.btn, opacity: ok ? 1 : .4 }} disabled={!ok}
                  onClick={() => onConfirm(reason.trim(), minutes)}>Confirm</button>
        </div>
      </div>
    </div>
  );
}

