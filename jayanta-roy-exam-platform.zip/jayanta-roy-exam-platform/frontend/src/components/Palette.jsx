// The question palette: every Indian aspirant reads this grid instinctively.
// Color encodes status; shape encodes marked-for-review. This is the signature
// element of the interface — kept precise and quiet.

function statusColor(st) {
  switch (st) {
    case "answered": return { bg: "var(--st-answered)", fg: "#fff" };
    case "marked": return { bg: "var(--st-marked)", fg: "#fff" };
    case "marked_answered": return { bg: "var(--st-marked)", fg: "#fff" };
    case "not_answered": return { bg: "var(--st-not)", fg: "#fff" };
    default: return { bg: "var(--st-notvisited)", fg: "var(--text)" };
  }
}

const LEGEND = [
  ["answered", "Answered"],
  ["not_answered", "Not answered"],
  ["marked", "Marked for review"],
  ["marked_answered", "Answered & marked"],
  ["not_visited", "Not visited"],
];

export default function Palette({ order, statuses, current, onJump }) {
  return (
    <div>
      <div style={{ fontFamily: "var(--mono)", fontSize: 11, letterSpacing: ".14em",
                    textTransform: "uppercase", color: "var(--muted)", marginBottom: 12 }}>
        Question palette
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 7 }}>
        {order.map((qid, i) => {
          const st = statuses[qid] || "not_visited";
          const c = statusColor(st);
          const isCurrent = i === current;
          const tick = st === "marked_answered";
          return (
            <button key={qid} onClick={() => onJump(i)} title={`Question ${i + 1}`}
              style={{
                position: "relative", height: 38, borderRadius: 6, fontFamily: "var(--mono)",
                fontSize: 13, fontWeight: 600, background: c.bg, color: c.fg,
                border: isCurrent ? "2px solid var(--ink)" : "1px solid rgba(0,0,0,.08)",
              }}>
              {i + 1}
              {tick && <span style={{
                position: "absolute", right: 2, bottom: 0, fontSize: 11, color: "#7dffb0" }}>✓</span>}
            </button>
          );
        })}
      </div>

      <div style={{ marginTop: 18, display: "grid", gap: 7 }}>
        {LEGEND.map(([st, label]) => {
          const c = statusColor(st);
          return (
            <div key={st} style={{ display: "flex", alignItems: "center", gap: 9, fontSize: 12.5, color: "var(--muted)" }}>
              <span style={{ width: 16, height: 16, borderRadius: 4, background: c.bg,
                             border: "1px solid rgba(0,0,0,.1)", flexShrink: 0 }} />
              {label}
            </div>
          );
        })}
      </div>
    </div>
  );
}
