# Exam Platform — Architecture & Scaling to Millions

This document is the real answer to "handle millions of candidates." The code in
this repo is a **correct reference implementation of the patterns**; this doc is
how those patterns scale, plus the things a demo can't show but a real exam body
(NTA-grade) must get right.

Read this before you show anyone the code. The code is the easy 20%. The
decisions below are the 80% that decides whether the exam survives 9:00 AM.

---

## 1. The core scaling insight

A million candidates is **not** a million requests per second. Model it:

- 1,000,000 candidates, 3-hour exam, saving an answer roughly every 20–30s.
- Steady-state answer writes: ~1,000,000 / 25s ≈ **40,000 writes/sec**.
- Reads (question paper) happen **once per candidate at start** and should never
  hit your database — serve them from CDN/Redis.
- The killer is not steady state. It's **correlated events**:
  - **Login storm** at T-0 (everyone at 9:00 AM).
  - **Submit storm** at T-end (everyone in the last 2 minutes).

Everything in this design exists to flatten those two spikes and to keep the
per-answer write off the relational database.

### Why this stack survives it

| Pressure | Naive design | This design |
|---|---|---|
| 40k answer writes/s | INSERT per answer → Postgres melts | Write to Redis (in-memory, ~200k+ ops/s per node, sharded), flush to Postgres in batches asynchronously |
| Paper reads | SELECT questions per candidate | Paper cached in Redis / pushed to CDN as a static signed blob |
| Login storm | All hit auth + DB at once | Staggered login windows + stateless JWT (no session table) + read replicas |
| Submit storm | Recompute + write per submit | Score reads from Redis hash already in memory; result row is one upsert |
| A pod dies | In-memory session lost | Pods are stateless; all session state is in Redis |

---

## 2. Component map

```
                         ┌─────────────┐
        Candidates ─────▶│     CDN     │  static SPA + signed question packages
                         └──────┬──────┘
                                │ /api/*
                         ┌──────▼──────┐
                         │ Global LB   │  (ALB / Cloud LB)  TLS termination
                         └──────┬──────┘
                    ┌───────────┼───────────┐
              ┌─────▼───┐  ┌────▼────┐  ┌───▼─────┐   Stateless API pods
              │  api-1  │  │  api-2  │  │  api-N  │   (FastAPI, autoscaled)
              └────┬────┘  └────┬────┘  └────┬────┘
                   └────────────┼────────────┘
                   ┌────────────┼─────────────┐
          ┌────────▼───────┐        ┌─────────▼────────┐
          │  Redis Cluster │        │   Kafka / queue  │  (answer flush stream)
          │ (sharded by    │        └─────────┬────────┘
          │  attempt_id)   │                  │
          └────────┬───────┘        ┌─────────▼────────┐
                   │                │  Flush workers   │
                   │                └─────────┬────────┘
                   ▼                          ▼
          hot session state          ┌────────────────┐
                                     │  Postgres      │  (Aurora / Cloud SQL)
                                     │  primary +     │  durable audit + results
                                     │  read replicas │
                                     └────────────────┘
```

In THIS repo the flush workers and sweeper run in-process (`services/background.py`)
so it runs on a laptop. The only change to go to the diagram above is moving those
loops into a separate worker Deployment fed by Kafka. The logic is identical.

---

## 3. The hot path, precisely

### Answer save (the 40k/s path)
1. Client batches changed answers, each tagged with a monotonic `version`.
2. `PUT /attempts/{id}/answers` → a **Lua script** runs atomically in Redis:
   - reject if attempt closed or past `deadline + grace`
   - reject if incoming `version` ≤ stored `version` (idempotent, safe retries)
   - else write the answer to the attempt's hash, mark attempt "dirty"
3. Returns immediately. **Postgres is not touched.**

A background flusher pops dirty attempts and bulk-upserts their answers to
Postgres every few seconds (`ON CONFLICT ... WHERE version < excluded.version`).
The relational DB sees **batched, deduplicated** writes at a rate you control,
not the raw 40k/s.

### Why version numbers matter (this is the subtle correctness bit)
Networks retry. A candidate on 3G taps B, the request stalls, they tap C, the
retry of B arrives after C. Without versioning you just recorded B — a wrong
answer the candidate never intended. With versioning, C has a higher version and
B's late arrival is rejected as STALE. **This is the difference between a fair
exam and a lawsuit.** The test suite (`test_flow.py`) proves this case.

### Server-authoritative time
The countdown is anchored to `server_time` returned at load; the client computes
a fixed offset and never trusts the device clock again. The deadline is enforced
**server-side** in the Lua script — changing your laptop clock buys nothing. A
sweeper auto-submits anyone whose deadline passes without a manual submit (closed
browser, crash, dead battery).

---

## 4. Flattening the two storms

### Login storm — staggered windows (the single most important operational lever)
NTA does not let 2M people start at the same instant, and neither should you. The
`Exam` model has a `window_start`/`window_end`. Real deployments assign candidates
to **shifts and reporting slots** (e.g. entry 8:00–8:30, exam 9:00). Combined with:
- **Stateless JWT auth** — no session lookup, no session table to contend on.
- **Auth on read replicas** — login only reads the user row.
- **Rate-limited, queued entry** — a virtual waiting room (see §7) if a spike
  still forms.

### Submit storm — it's already absorbed
Scoring reads the answer hash that's **already in Redis memory** and writes **one**
result row. No question re-fetch from disk (correct-answer key is small, cacheable).
The expensive part (per-answer persistence) already happened gradually via the
flusher during the exam, not in a spike at the end.

---

## 5. What a demo hides but production must have

I'm flagging these explicitly because leaving them implicit would be dishonest —
this repo does **not** implement all of them, and you should not tell anyone it's
"exam-ready" until these exist.

### 5.1 Security & anti-cheating (the actual hard problem)
- **Question paper secrecy**: papers must be encrypted at rest and only decrypted
  in the candidate's session after the window opens. A leaked paper is a national
  news event. This repo serves plaintext from Redis — fine for a demo, unacceptable
  live.
- **Per-candidate question/option shuffling** (implemented for questions; extend to
  options) to make screen-sharing collusion harder.
- **Proctoring**: webcam + screen monitoring, tab-switch detection, fullscreen
  lock, copy-paste blocking, second-face/second-voice detection. This is usually a
  specialist vendor integration, not something you build from scratch.
- **Impersonation**: biometric/photo match at entry is an operational control, not
  a software feature you can fully own.

### 5.2 Durability & audit
- Redis is the hot copy; **Postgres is the legal record**. AOF on Redis + frequent
  flush bounds data loss to seconds. For a real exam you want the flush interval
  low and Redis in a replicated cluster with AOF `everysec` at minimum.
- **Every answer mutation should be event-sourced** (append-only log, e.g. Kafka)
  so you can replay and prove exactly what a candidate submitted and when. Results
  disputes are resolved from this log.
- **Idempotent submit** is implemented — double-clicks and retries can't corrupt a
  score.

### 5.3 Accessibility & fairness
- WCAG AA: keyboard nav, screen-reader labels, scalable text, reduced-motion
  (the frontend respects `prefers-reduced-motion` and has visible focus).
- **Compensatory time** ("scribe"/PwD candidates get +20 min) — the deadline is
  per-attempt, so this is a per-candidate deadline override, easy to add.
- Low-bandwidth mode: the batched, retrying answer sync already tolerates flaky
  networks; a full offline-capable client (Service Worker) is the next step.

### 5.4 Multi-format questions
MCQ is built. The `Question.options` JSON + a `type` discriminator extends cleanly to:
- **Multiple-correct (MSQ)** — JEE Advanced style, partial marking.
- **Numerical/integer answer** — store a numeric range instead of an option key.
- **Comprehension/linked sets** — a `passage_id` grouping questions.
- **Match-the-following** — options as pairs.
The scoring function is the only place that needs per-type logic; isolate it behind
a `score_question(type, response, key)` strategy.

---

## 6. Data & capacity sizing (order-of-magnitude)

For 2,000,000 candidates × 180 questions:
- **Answers**: 360M rows. Partition the `answers` table by `exam_id` (or hash of
  `attempt_id`). One exam's data is one partition set you can archive/drop wholesale.
- **Redis memory**: ~a few hundred bytes/answer in the hash × active answers. Size
  the cluster for peak concurrent attempts, not total candidates — shifts keep
  concurrency well below the 2M headline.
- **Postgres**: primary for writes (fed only by batched flushes) + read replicas
  for auth, dashboards, post-exam analytics. Aurora/Cloud SQL with 1 primary +
  N replicas.
- **Redis Cluster**: shard by `attempt_id`. The key naming in `redis_client.py`
  already uses hash tags `{attempt_id}` so all of one attempt's keys live on one
  shard — required for the Lua script to run atomically (Lua can't span shards).

---

## 7. Virtual waiting room (the spike insurance)

Even with staggered windows, put a token-bucket admission gate in front of
`/start`. Candidates past the rate get a "you're in the queue, position N" page and
are admitted as capacity frees. This converts a potential outage into a few
candidates waiting 30 seconds — which is recoverable and fair, whereas a crash at
9:00 AM is neither. Implement with a Redis counter + a lightweight SSE/poll.

---

## 8. Deployment (costing is not a concern → do it right)

- **Kubernetes** (EKS/GKE) for the API and workers.
  - HPA on CPU **and** a custom metric (Redis dirty-set length / request latency).
  - PodDisruptionBudgets so rolling deploys never drop below quorum during an exam
    (better: **freeze deploys during exam windows**).
  - Multi-AZ node pools; ideally the whole exam runs active-active across ≥2 AZs.
- **Redis**: managed cluster (ElastiCache/MemoryStore), Multi-AZ, AOF on.
- **Postgres**: Aurora/Cloud SQL, Multi-AZ primary + read replicas + PITR.
- **CDN** (CloudFront/Cloud CDN) for the SPA and signed question packages.
- **Observability**: Prometheus + Grafana (RED metrics per endpoint), distributed
  tracing, and a **live exam war-room dashboard** — active attempts, save latency
  p99, flush lag, error rate. During NEET/JEE this dashboard is staffed live.
- **Game-day load tests** against a production-clone at 1.5× expected peak, weeks
  before. The Locust file here is the seed of that — the real one runs from many
  distributed workers. **No amount of clean code substitutes for having actually
  pushed the real infra to peak load once.**

---

## 9. Why Python/FastAPI here, and when to pick the JVM

Chosen: **FastAPI + async SQLAlchemy + Redis**, **React** frontend.
- The bottleneck at exam scale is **I/O and architecture, not language**. The hot
  path is "one Redis round-trip"; a faster language shaves microseconds off
  something already dominated by network + Redis.
- Async Python handles tens of thousands of concurrent connections per pod cheaply,
  and you scale pods horizontally regardless.
- You (Abhi) have 3 years of Python — you can actually extend and operate this.

**When the JVM (Java/Spring/Vert.x or Go) genuinely wins:**
- If you want the flush/stream workers as a high-throughput Kafka consumer, the JVM
  ecosystem (Kafka Streams) is more mature and Go/Java give steadier GC/latency
  under sustained load.
- A common real architecture is **polyglot**: async Python or Go for the stateless
  API edge, JVM for the streaming/scoring pipeline. That's a legitimate choice, not
  resume-driven. Picking Java for the *whole* thing just to look enterprise would be.

---

## 10. Honest status of this repo

**Proven working (tested end-to-end in `test_flow.py`):** login, start, resume,
version-guarded idempotent answer saves, stale-write rejection, server-authoritative
deadline enforcement, NEET-style +4/−1 scoring, idempotent submit, post-submit
lockout, async flush to Postgres, auto-submit sweeper.

**Reference-quality but simplified:** Redis is single-node in compose (cluster in
prod); flush/sweeper run in-process (dedicated workers in prod); PBKDF2 hashing
(use argon2 in prod); question paper served plaintext (encrypt + CDN in prod).

**Deliberately NOT built (specialist / operational, called out so nobody is
misled):** proctoring, biometric entry, encrypted paper distribution, the virtual
waiting room, full WCAG audit, MSQ/numerical question types. §5 and §7 tell you
exactly what each requires.

This is a strong, honest foundation that demonstrates every core distributed-systems
pattern the real thing uses — and it's small enough that you can run it, read all of
it, and defend every line in an interview.
